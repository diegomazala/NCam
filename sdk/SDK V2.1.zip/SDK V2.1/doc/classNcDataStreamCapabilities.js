var classNcDataStreamCapabilities =
[
    [ "CapabilitiesPacket", "structNcDataStreamCapabilities_1_1CapabilitiesPacket.html", "structNcDataStreamCapabilities_1_1CapabilitiesPacket" ],
    [ "PacketType_t", "classNcDataStreamCapabilities.html#a68776d6f6c0de1b3cec269fd0a585abc", null ],
    [ "TimeCode_t", "classNcDataStreamCapabilities.html#a3f9e3c7306e4ef3350b0f65c356a51f6", null ],
    [ "ePacketType", "classNcDataStreamCapabilities.html#a0afdbb7bcaab33b157d075d0d51c721b", [
      [ "UnknownType", "classNcDataStreamCapabilities.html#a0afdbb7bcaab33b157d075d0d51c721ba67818239fab08b94f69062b033206083", null ],
      [ "CameraTracking", "classNcDataStreamCapabilities.html#a0afdbb7bcaab33b157d075d0d51c721ba32f1fd2c4d7185bf63ed3c4d71981eb2", null ],
      [ "DepthImage", "classNcDataStreamCapabilities.html#a0afdbb7bcaab33b157d075d0d51c721ba01e546c0752623a6530df4e2ed6b4bde", null ],
      [ "FilmImage", "classNcDataStreamCapabilities.html#a0afdbb7bcaab33b157d075d0d51c721ba0f9c462d01f83492e6f57ec5a999401b", null ],
      [ "CompositeImage", "classNcDataStreamCapabilities.html#a0afdbb7bcaab33b157d075d0d51c721ba37c925e23fef4546cf30c33d496b78e3", null ],
      [ "DistortMap", "classNcDataStreamCapabilities.html#a0afdbb7bcaab33b157d075d0d51c721baee84b7390d2c945ce76fe634fe7898cc", null ],
      [ "OpticalParameters", "classNcDataStreamCapabilities.html#a0afdbb7bcaab33b157d075d0d51c721ba20ce37a256f82c919bb9e56b41d49cb2", null ],
      [ "Capabilities", "classNcDataStreamCapabilities.html#a0afdbb7bcaab33b157d075d0d51c721ba8a7d1aa9e0fef11c2eac5a887318bfba", null ],
      [ "Query", "classNcDataStreamCapabilities.html#a0afdbb7bcaab33b157d075d0d51c721ba05e01648e377738cb198e4d76b6035d3", null ],
      [ "TypeMask", "classNcDataStreamCapabilities.html#a0afdbb7bcaab33b157d075d0d51c721baa636f9e6ab84e306279d1baec53862c7", null ]
    ] ],
    [ "NcDataStreamCapabilities", "classNcDataStreamCapabilities.html#adf0d24d71e5c7dcbc91d365710c21342", null ],
    [ "~NcDataStreamCapabilities", "classNcDataStreamCapabilities.html#a79dd25ba7ee63d0c606d049b1f4328c5", null ],
    [ "GetSizeInBytes", "classNcDataStreamCapabilities.html#a9a8adb67ed29471b02cbd1de19f7d666", null ],
    [ "GetPacketType", "classNcDataStreamCapabilities.html#abbd9ec03c0320400031d6841b1cbb441", null ],
    [ "GetData", "classNcDataStreamCapabilities.html#a3da6d6c4bf24a967b9365322904206c5", null ],
    [ "GetData", "classNcDataStreamCapabilities.html#a1e2d35ce26236778963437bf3582d916", null ],
    [ "Ptr", "classNcDataStreamCapabilities.html#ad246fc98dd0dbaf6c1baa8d52d9e1d1b", null ],
    [ "Ptr", "classNcDataStreamCapabilities.html#a98aca466af7fa72fcdb908e1ea232ee0", null ],
    [ "ToPtr", "classNcDataStreamCapabilities.html#a0021c559ec3d619d77d42b819dab3783", null ],
    [ "ToPtr", "classNcDataStreamCapabilities.html#a5fe48ffe08f44ddadeba96cb7d021bc7", null ],
    [ "FromPtr", "classNcDataStreamCapabilities.html#ae30c6570e2138e8fda5466a38ffe28d7", null ],
    [ "FromPtr", "classNcDataStreamCapabilities.html#a925ec1c2b3af76daa5e659089836cc53", null ],
    [ "OnDecodingFromPtrError", "classNcDataStreamCapabilities.html#ac3173d3bb28fa8dbf4ec29201f279099", null ]
];