var structNcDataStreamImage_1_1NcTrackStreamImageHeader =
[
    [ "mPacketType", "structNcDataStreamImage_1_1NcTrackStreamImageHeader.html#a4c25137c67dec67c22c5994b63d309e1", null ],
    [ "mChannels", "structNcDataStreamImage_1_1NcTrackStreamImageHeader.html#a66e96943ac3ab7a0ec5304e65434cf6d", null ],
    [ "mDepth", "structNcDataStreamImage_1_1NcTrackStreamImageHeader.html#a248c724a99c6ccdb979bc5318e33a05a", null ],
    [ "mWidth", "structNcDataStreamImage_1_1NcTrackStreamImageHeader.html#a7c0b1822b47b72b2f236fd5abddabb65", null ],
    [ "mHeight", "structNcDataStreamImage_1_1NcTrackStreamImageHeader.html#a105512ed7c7a910a829916f112735b34", null ],
    [ "mTimeCode", "structNcDataStreamImage_1_1NcTrackStreamImageHeader.html#af3d93b5fc1d9cd0733fc6d679fb7acf3", null ]
];