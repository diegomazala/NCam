var structNcDataStreamQuery_1_1QueryPacket =
[
    [ "mPacketType", "structNcDataStreamQuery_1_1QueryPacket.html#a82883b700013dfd1866a5a700ee55b0b", null ],
    [ "mPacketsToActivate", "structNcDataStreamQuery_1_1QueryPacket.html#a5f55003ff6c419df66c0179fdc17cedd", null ]
];