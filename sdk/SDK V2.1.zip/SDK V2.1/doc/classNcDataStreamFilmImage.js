var classNcDataStreamFilmImage =
[
    [ "PacketType_t", "classNcDataStreamFilmImage.html#a68776d6f6c0de1b3cec269fd0a585abc", null ],
    [ "TimeCode_t", "classNcDataStreamFilmImage.html#a3f9e3c7306e4ef3350b0f65c356a51f6", null ],
    [ "Channels", "classNcDataStreamFilmImage.html#a8769b19ae80f367f3edc782190425542", [
      [ "UnknownChannels", "classNcDataStreamFilmImage.html#a8769b19ae80f367f3edc782190425542af9fb06a398f22b216bb6df9135706b2e", null ],
      [ "Nc1Channel", "classNcDataStreamFilmImage.html#a8769b19ae80f367f3edc782190425542ab4c94ece30f04e329b7783ca0bbd62f2", null ],
      [ "Nc2Channels", "classNcDataStreamFilmImage.html#a8769b19ae80f367f3edc782190425542a1e91381ebf1d8415ae4f3deb4a125ad5", null ],
      [ "NcRGB", "classNcDataStreamFilmImage.html#a8769b19ae80f367f3edc782190425542a260a41966e043c528775d45cb5b0b904", null ],
      [ "NcRGBD", "classNcDataStreamFilmImage.html#a8769b19ae80f367f3edc782190425542a8abc384b1334959383fe17a98a052e2f", null ]
    ] ],
    [ "Depth", "classNcDataStreamFilmImage.html#abbf986e42def91eca4c9088f0a51a6a8", [
      [ "UnknownDepth", "classNcDataStreamFilmImage.html#abbf986e42def91eca4c9088f0a51a6a8ac3a66c461338595b064cb5a88f7689ce", null ],
      [ "OneBytePerPixel", "classNcDataStreamFilmImage.html#abbf986e42def91eca4c9088f0a51a6a8a698e23d373a1c26f87705d2753128769", null ],
      [ "OneFloatPerPixel", "classNcDataStreamFilmImage.html#abbf986e42def91eca4c9088f0a51a6a8a691a18fbe7d64c2889f17a29b9abe2f3", null ]
    ] ],
    [ "ePacketType", "classNcDataStreamFilmImage.html#a0afdbb7bcaab33b157d075d0d51c721b", [
      [ "UnknownType", "classNcDataStreamFilmImage.html#a0afdbb7bcaab33b157d075d0d51c721ba67818239fab08b94f69062b033206083", null ],
      [ "CameraTracking", "classNcDataStreamFilmImage.html#a0afdbb7bcaab33b157d075d0d51c721ba32f1fd2c4d7185bf63ed3c4d71981eb2", null ],
      [ "DepthImage", "classNcDataStreamFilmImage.html#a0afdbb7bcaab33b157d075d0d51c721ba01e546c0752623a6530df4e2ed6b4bde", null ],
      [ "FilmImage", "classNcDataStreamFilmImage.html#a0afdbb7bcaab33b157d075d0d51c721ba0f9c462d01f83492e6f57ec5a999401b", null ],
      [ "CompositeImage", "classNcDataStreamFilmImage.html#a0afdbb7bcaab33b157d075d0d51c721ba37c925e23fef4546cf30c33d496b78e3", null ],
      [ "DistortMap", "classNcDataStreamFilmImage.html#a0afdbb7bcaab33b157d075d0d51c721baee84b7390d2c945ce76fe634fe7898cc", null ],
      [ "OpticalParameters", "classNcDataStreamFilmImage.html#a0afdbb7bcaab33b157d075d0d51c721ba20ce37a256f82c919bb9e56b41d49cb2", null ],
      [ "Capabilities", "classNcDataStreamFilmImage.html#a0afdbb7bcaab33b157d075d0d51c721ba8a7d1aa9e0fef11c2eac5a887318bfba", null ],
      [ "Query", "classNcDataStreamFilmImage.html#a0afdbb7bcaab33b157d075d0d51c721ba05e01648e377738cb198e4d76b6035d3", null ],
      [ "TypeMask", "classNcDataStreamFilmImage.html#a0afdbb7bcaab33b157d075d0d51c721baa636f9e6ab84e306279d1baec53862c7", null ]
    ] ],
    [ "NcDataStreamFilmImage", "classNcDataStreamFilmImage.html#a72830fd64800b3453d3283ff29df0de6", null ],
    [ "~NcDataStreamFilmImage", "classNcDataStreamFilmImage.html#a46023315f600a801ec97d3d92e0a8249", null ],
    [ "GetSizeInBytes", "classNcDataStreamFilmImage.html#ac146384e1c350c7942c5c8ec8abd00c9", null ],
    [ "GetPacketType", "classNcDataStreamFilmImage.html#ab0e9776c76d23735a8c5fa66d01b520e", null ],
    [ "FromPtr", "classNcDataStreamFilmImage.html#ab393b31f0dbb5de349063e3a0577073b", null ],
    [ "FromPtr", "classNcDataStreamFilmImage.html#a925ec1c2b3af76daa5e659089836cc53", null ],
    [ "SetTimeCode", "classNcDataStreamFilmImage.html#a66a32752a695ddb9b53b53ff88ee974b", null ],
    [ "SetSize", "classNcDataStreamFilmImage.html#a4e9390e82abbeaf6d096e46a9a97b60d", null ],
    [ "GetSize", "classNcDataStreamFilmImage.html#ae257b3fa47b10de4b8473cb3ec8869b6", null ],
    [ "GetWidth", "classNcDataStreamFilmImage.html#a0d71f82f2273f461746dfc8bb130f248", null ],
    [ "GetHeight", "classNcDataStreamFilmImage.html#a02fe6f639333520673f373fd7a2b7ebf", null ],
    [ "GetChannels", "classNcDataStreamFilmImage.html#a4bcdb0e5035ce29fe0e92d9053b70b62", null ],
    [ "GetDepth", "classNcDataStreamFilmImage.html#a3be536fa0c0425b5dfeb6be518f38cc2", null ],
    [ "GetImagePtr", "classNcDataStreamFilmImage.html#aa0765a2fe5acca3e0a1b061cc54f720b", null ],
    [ "GetImagePtr", "classNcDataStreamFilmImage.html#a021b32bdd865b641ce8e842ba7b6879a", null ],
    [ "GetImageSizeInBytes", "classNcDataStreamFilmImage.html#a4b68ea71e07a919235493ac87cea7013", null ],
    [ "Ptr", "classNcDataStreamFilmImage.html#a8cc1808998430fc03d438b27cdbf768a", null ],
    [ "Ptr", "classNcDataStreamFilmImage.html#aa1f26e02048676d452ba80f7aaa2dfff", null ],
    [ "GetHeaderInBytes", "classNcDataStreamFilmImage.html#a1a0c0df35e7acd196c0ebc885ec8d371", null ],
    [ "UpdateImageSize", "classNcDataStreamFilmImage.html#a6fe18aa0dfd17b1f9a77055565b45257", null ],
    [ "ToPtr", "classNcDataStreamFilmImage.html#a0021c559ec3d619d77d42b819dab3783", null ],
    [ "ToPtr", "classNcDataStreamFilmImage.html#a5fe48ffe08f44ddadeba96cb7d021bc7", null ],
    [ "OnDecodingFromPtrError", "classNcDataStreamFilmImage.html#ac3173d3bb28fa8dbf4ec29201f279099", null ],
    [ "mData", "classNcDataStreamFilmImage.html#ac9a886f826600bfb7777a011861eb660", null ],
    [ "mPreviousImageSizeInBytes", "classNcDataStreamFilmImage.html#a44bb2531558da33e23f62ebd16ca16e4", null ]
];