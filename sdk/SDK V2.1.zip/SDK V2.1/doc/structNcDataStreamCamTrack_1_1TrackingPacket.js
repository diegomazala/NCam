var structNcDataStreamCamTrack_1_1TrackingPacket =
[
    [ "mPacketType", "structNcDataStreamCamTrack_1_1TrackingPacket.html#a819caa475fed46b508894e8822c6454e", null ],
    [ "mZoomEncoder", "structNcDataStreamCamTrack_1_1TrackingPacket.html#a4f2915b8a7215d1563644130fa26ebf6", null ],
    [ "mFocusEncoder", "structNcDataStreamCamTrack_1_1TrackingPacket.html#a86886f8031592933899627a849d30e51", null ],
    [ "mIrisEncoder", "structNcDataStreamCamTrack_1_1TrackingPacket.html#a30b0590aaefe3817031bbb07b822417e", null ],
    [ "mCamFromWorld", "structNcDataStreamCamTrack_1_1TrackingPacket.html#af3aa836aec10c9689650df81212e3244", null ],
    [ "mTimeCode", "structNcDataStreamCamTrack_1_1TrackingPacket.html#a6e30c4648d218460e9788391131d4500", null ]
];