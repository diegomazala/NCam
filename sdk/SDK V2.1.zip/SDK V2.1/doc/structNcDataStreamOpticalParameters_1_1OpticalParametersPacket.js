var structNcDataStreamOpticalParameters_1_1OpticalParametersPacket =
[
    [ "mPacketType", "structNcDataStreamOpticalParameters_1_1OpticalParametersPacket.html#a8090138d70736bb2c2ae4c7e1f79f3e1", null ],
    [ "mFovInDegrees", "structNcDataStreamOpticalParameters_1_1OpticalParametersPacket.html#a1892f45eb81b61afd9fd4e0cd8804da4", null ],
    [ "mProjectionCenterNormalized", "structNcDataStreamOpticalParameters_1_1OpticalParametersPacket.html#a29f683999481815f4b6b411139edb479", null ],
    [ "mDistortionType", "structNcDataStreamOpticalParameters_1_1OpticalParametersPacket.html#a38789b0e4e07ec909f51c2d8f4bc656c", null ],
    [ "mImageSensorSizeInMm", "structNcDataStreamOpticalParameters_1_1OpticalParametersPacket.html#a937e7fb10919e8aeb15cd4b64a0f31f9", null ],
    [ "mImageResolution", "structNcDataStreamOpticalParameters_1_1OpticalParametersPacket.html#a1f48cde1f360d349ee025980af6ffed3", null ],
    [ "mImageAspectRatio", "structNcDataStreamOpticalParameters_1_1OpticalParametersPacket.html#a6750ab575938ddb2e869c7e14bd136ba", null ],
    [ "mTop", "structNcDataStreamOpticalParameters_1_1OpticalParametersPacket.html#a1ce39dc89f4d74994d6b3393ac5cb466", null ],
    [ "mBottom", "structNcDataStreamOpticalParameters_1_1OpticalParametersPacket.html#a7915129b8f76e8cfd94803d44e6ba816", null ],
    [ "mLeft", "structNcDataStreamOpticalParameters_1_1OpticalParametersPacket.html#a80694245bb12e5fee5ab89a96fb81447", null ],
    [ "mRight", "structNcDataStreamOpticalParameters_1_1OpticalParametersPacket.html#a6fca27f3376772dc6b9b0b844845d586", null ],
    [ "mDistortionParameters", "structNcDataStreamOpticalParameters_1_1OpticalParametersPacket.html#a5333605d7d0f8cbe7c1ef179be6496db", null ],
    [ "mTimeCode", "structNcDataStreamOpticalParameters_1_1OpticalParametersPacket.html#acbe09b017660d8c4f2eda4331349453b", null ]
];