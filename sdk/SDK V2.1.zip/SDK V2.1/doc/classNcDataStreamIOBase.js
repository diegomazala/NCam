var classNcDataStreamIOBase =
[
    [ "IpPort_t", "classNcDataStreamIOBase.html#a04c3c1d1a70ab24fc9438b6f4c85521e", null ],
    [ "NcDataStreamIOBase", "classNcDataStreamIOBase.html#a1f7b0c880dac4a94ad622c44a4825b1b", null ],
    [ "~NcDataStreamIOBase", "classNcDataStreamIOBase.html#a8ec9e5a6bc0f9dc783533dcefd8d5928", null ],
    [ "StartStreaming", "classNcDataStreamIOBase.html#aa7ae2a9ee6c9a7d022164562db23623d", null ],
    [ "StopStreaming", "classNcDataStreamIOBase.html#a1071183a607c2c3bfecd0d11ac9d037e", null ],
    [ "DoStreaming", "classNcDataStreamIOBase.html#a206d12cbe1211869b71e80fad093c601", null ],
    [ "IsConnected", "classNcDataStreamIOBase.html#a66062b26881197e75f1ae178cc03b59b", null ],
    [ "GetPort", "classNcDataStreamIOBase.html#a8945fea271b73f82315084e9f4b854f3", null ],
    [ "OnStartStreamingError", "classNcDataStreamIOBase.html#a0db4c5b620a51d16ae6c8e2cebd4a543", null ],
    [ "OnStopStreamingError", "classNcDataStreamIOBase.html#a8b194c76fa938da9e887085f384a06e2", null ],
    [ "OnDoStreamingError", "classNcDataStreamIOBase.html#af9551c63baa46a2bbd9410367435d9d1", null ],
    [ "Read", "classNcDataStreamIOBase.html#ad79267408599844d6b28b01e441cd61d", null ],
    [ "Write", "classNcDataStreamIOBase.html#aa204ad5c24ace05b290ec4a4bdfc959f", null ],
    [ "WaitAndGetANewPacket", "classNcDataStreamIOBase.html#af03bb6555fe9ef5fa57837a34981d7f2", null ],
    [ "SendPacket", "classNcDataStreamIOBase.html#a97fdd21ae5dcdbe16508990cc44c0bee", null ],
    [ "InternalOpen", "classNcDataStreamIOBase.html#a2b4b5726e8edd5d8211d6294ad1d9e5f", null ],
    [ "InternalClose", "classNcDataStreamIOBase.html#a875be7474976c397e8cef1fbccf8e9cc", null ],
    [ "InternalRead", "classNcDataStreamIOBase.html#ae967317916913c0a8dd6836df1260c2d", null ],
    [ "InternalWrite", "classNcDataStreamIOBase.html#ac18576dbd51a8e3ada4b59c844d50ad8", null ],
    [ "mIpPort", "classNcDataStreamIOBase.html#af9fb9479e9d46775977a18e473b09a89", null ]
];