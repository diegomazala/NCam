var classNcDataBufferSwap =
[
    [ "NcDataBufferSwap", "classNcDataBufferSwap.html#a6a29c118f6db08c82f117d57c6bd02fe", null ],
    [ "~NcDataBufferSwap", "classNcDataBufferSwap.html#a30fe3bf6c5110c90f741fe92e0a472ec", null ],
    [ "WaitForNewProductAvailable", "classNcDataBufferSwap.html#a94d37fb385a55f2b4885ac013a2e7dec", null ],
    [ "IsNewProductAvailable", "classNcDataBufferSwap.html#aa6e434523e81592a3431eede1fc6f2c2", null ],
    [ "GetLastBuffer", "classNcDataBufferSwap.html#a543e390b02a97dc4c3480e2423696f0e", null ],
    [ "MapConsumerBuffer", "classNcDataBufferSwap.html#aacb07fa3e5bce3476c6294b7e57e57d8", null ],
    [ "UnMapConsumerBuffer", "classNcDataBufferSwap.html#ab36f6f4353c5a52f20016a245a4609e0", null ],
    [ "MapProductorBuffer", "classNcDataBufferSwap.html#a9d9f8ad00851f96ee7ef8ce774759eef", null ],
    [ "UnMapProductorBuffer", "classNcDataBufferSwap.html#a421574c32a35cb22c5827101f12758f5", null ],
    [ "mUsedRessourceBufferId", "classNcDataBufferSwap.html#ae92c8d5f93d8a3aa14f7560e0962762a", null ],
    [ "mProductedBufferId", "classNcDataBufferSwap.html#a9b605dac9c50c1c2df670fa6be76af6e", null ],
    [ "mProductorCurrentBufferId", "classNcDataBufferSwap.html#ade3b56a437b3016eeaa5a3b00ae51ced", null ],
    [ "mSomethingProduced", "classNcDataBufferSwap.html#a682002f3a7d621c796a29bb2eb9c5616", null ],
    [ "mDataArray", "classNcDataBufferSwap.html#a1130c8a17c06485d92881eefc6e3fa52", null ]
];