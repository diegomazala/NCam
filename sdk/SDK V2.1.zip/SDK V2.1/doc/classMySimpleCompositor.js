var classMySimpleCompositor =
[
    [ "MySimpleCompositor", "classMySimpleCompositor.html#a0bdc73838a47f7c6956ded3995dd1744", null ],
    [ "~MySimpleCompositor", "classMySimpleCompositor.html#ab0b14221207792747d54bf0492a3933a", null ],
    [ "BeginRenderCGToTexture", "classMySimpleCompositor.html#ad3a9d6304974e54b401d2185c26bcc73", null ],
    [ "EndRenderCGToTexture", "classMySimpleCompositor.html#af668acabfd9c9ee821fd3f8cea056e14", null ],
    [ "DoCompositing", "classMySimpleCompositor.html#acdf823f49402ea6deac858780c686b24", null ],
    [ "SetAspectRatioViewport", "classMySimpleCompositor.html#a6b1cdc1525024574ef7860e2ae18fc2b", null ],
    [ "InitializeGL", "classMySimpleCompositor.html#a1c8343bc72c039652c866f993cbc9bc2", null ],
    [ "UpdateDistortMap", "classMySimpleCompositor.html#a708848f3a8c4e86ffbd136ffe7cd3fd8", null ],
    [ "SetViewPort", "classMySimpleCompositor.html#afe42ce1a83a7c9a203de6c57d418db59", null ],
    [ "SetDistortMapResolution", "classMySimpleCompositor.html#a213455ec18a29ac58077472b816f2cef", null ],
    [ "CreateShader", "classMySimpleCompositor.html#a8ccfd1cfd325f5746cd00bd05edc91b6", null ],
    [ "DeleteShader", "classMySimpleCompositor.html#a0358fee47af10361ed74fb41d297acaf", null ],
    [ "CreateOrUpdateFBO", "classMySimpleCompositor.html#a1b025502b8322b38409c84ccb3b1ebfa", null ],
    [ "DeleteFBO", "classMySimpleCompositor.html#a33995d92b70aefe32bd8f9a93d3a0cfd", null ]
];