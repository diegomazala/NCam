var structNcDataStreamCapabilities_1_1CapabilitiesPacket =
[
    [ "mPacketType", "structNcDataStreamCapabilities_1_1CapabilitiesPacket.html#a1febd634eb810ba8ea3c73419695df5c", null ],
    [ "mAvailablePackets", "structNcDataStreamCapabilities_1_1CapabilitiesPacket.html#a89a94fbd60a3b0b5432f67ad69f54d89", null ],
    [ "mActivatedPackets", "structNcDataStreamCapabilities_1_1CapabilitiesPacket.html#ae987c7730bfa1d7b159bada1d634b894", null ]
];