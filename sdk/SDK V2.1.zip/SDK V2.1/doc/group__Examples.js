var group__Examples =
[
    [ "MyGUIClient", "group__MyGUIClient.html", "group__MyGUIClient" ],
    [ "MySimpleClient", "group__MySimpleClient.html", "group__MySimpleClient" ],
    [ "MySimpleClient_win32", "group__MySimpleClient__win32.html", "group__MySimpleClient__win32" ]
];