var searchData=
[
  ['edistortions',['eDistortions',['../classNcDataStreamOpticalParameters.html#adf762ef24b26d47b7a7f5dc3040cf021',1,'NcDataStreamOpticalParameters']]],
  ['epackettype',['ePacketType',['../classNcDataStreamBase.html#a0afdbb7bcaab33b157d075d0d51c721b',1,'NcDataStreamBase']]]
];
