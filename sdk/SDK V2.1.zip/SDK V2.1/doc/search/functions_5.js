var searchData=
[
  ['fromptr',['FromPtr',['../classNcDataStreamBase.html#ae30c6570e2138e8fda5466a38ffe28d7',1,'NcDataStreamBase::FromPtr(const uint8_t *lptr, const size_t &amp;lSize)'],['../classNcDataStreamBase.html#a925ec1c2b3af76daa5e659089836cc53',1,'NcDataStreamBase::FromPtr(const uint8_t(&amp;lptr)[lSize])'],['../classNcDataStreamImage.html#ab393b31f0dbb5de349063e3a0577073b',1,'NcDataStreamImage::FromPtr()']]]
];
