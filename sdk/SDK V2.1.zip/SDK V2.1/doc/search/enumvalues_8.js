var searchData=
[
  ['simpleanamorphic',['SimpleAnamorphic',['../classNcDataStreamOpticalParameters.html#adf762ef24b26d47b7a7f5dc3040cf021a89b5f846ffb70b2c3c48838f8a55bbc0',1,'NcDataStreamOpticalParameters']]],
  ['sphere',['Sphere',['../classMyTrackBall.html#a64ebdccccbf5a685ef76ed761eeccffaa29a0527ff28286eba05f51de466d366f',1,'MyTrackBall']]],
  ['spherical',['Spherical',['../classNcDataStreamOpticalParameters.html#adf762ef24b26d47b7a7f5dc3040cf021af40d1b63321ac21e478dbd35fec47641',1,'NcDataStreamOpticalParameters']]]
];
