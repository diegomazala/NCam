var searchData=
[
  ['sendpacket',['SendPacket',['../classNcDataStreamIOBase.html#a97fdd21ae5dcdbe16508990cc44c0bee',1,'NcDataStreamIOBase']]],
  ['setaspectratioviewport',['SetAspectRatioViewport',['../classMySimpleCompositor.html#a6b1cdc1525024574ef7860e2ae18fc2b',1,'MySimpleCompositor']]],
  ['setconnectionparameters',['SetConnectionParameters',['../classNcDataStreamClientBase.html#a1e83d4e62a821f9e1597b7a6d1e56c7a',1,'NcDataStreamClientBase']]],
  ['setdistortmapresolution',['SetDistortMapResolution',['../classMySimpleCompositor.html#a213455ec18a29ac58077472b816f2cef',1,'MySimpleCompositor']]],
  ['setrenderfromcam',['SetRenderFromCam',['../classMyGLWidget.html#a87d55f8a4dad9d99b0469a968f7e405f',1,'MyGLWidget']]],
  ['setsize',['SetSize',['../classNcDataStreamImage.html#a4e9390e82abbeaf6d096e46a9a97b60d',1,'NcDataStreamImage']]],
  ['settimecode',['SetTimeCode',['../classNcDataStreamImage.html#a66a32752a695ddb9b53b53ff88ee974b',1,'NcDataStreamImage']]],
  ['setvalue',['SetValue',['../classNcThreadSafeResource.html#a56cf53b3c00ffcda721de0462a0761bf',1,'NcThreadSafeResource']]],
  ['setviewport',['SetViewPort',['../classMySimpleCompositor.html#afe42ce1a83a7c9a203de6c57d418db59',1,'MySimpleCompositor']]],
  ['showpacket',['ShowPacket',['../group__MySimpleClient.html#ga64e6c59fb8ed01ec9d31b76f1fede6fc',1,'ShowPacket(const NcDataStreamCamTrack::TrackingPacket &amp;lPacket):&#160;main.cpp'],['../group__MySimpleClient__win32.html#ga64e6c59fb8ed01ec9d31b76f1fede6fc',1,'ShowPacket(const NcDataStreamCamTrack::TrackingPacket &amp;lPacket):&#160;main.cpp']]],
  ['signal_5fcallback_5fhandler',['signal_callback_handler',['../group__MySimpleClient.html#gadcbd8f7eaa3e001fdb750595e8564528',1,'signal_callback_handler(int):&#160;main.cpp'],['../group__MySimpleClient__win32.html#gadcbd8f7eaa3e001fdb750595e8564528',1,'signal_callback_handler(int):&#160;main.cpp']]],
  ['sizehint',['sizeHint',['../classMyGLWidget.html#abd49d2b071e74157dee1396ba45da0fc',1,'MyGLWidget']]],
  ['startclock',['StartClock',['../classMyTrackBall.html#a50e65c25a35e66ac65d68af727bd01f6',1,'MyTrackBall']]],
  ['startstreaming',['StartStreaming',['../classNcDataStreamClientBase.html#ad7d4084a6899dc0650043f459a6d9f81',1,'NcDataStreamClientBase::StartStreaming()'],['../classNcDataStreamIOBase.html#aa7ae2a9ee6c9a7d022164562db23623d',1,'NcDataStreamIOBase::StartStreaming()']]],
  ['startstreamingerror',['StartStreamingError',['../classMyGUIClient.html#adc9cfbcb886db26422524539ca2ae221',1,'MyGUIClient']]],
  ['stopclock',['StopClock',['../classMyTrackBall.html#ac29901f5c7de199bdf8fd2af686950a1',1,'MyTrackBall']]],
  ['stopexec',['StopExec',['../classMyGUIClient.html#a76237bb40862c31badd9e0943d5898ef',1,'MyGUIClient']]],
  ['stopstreaming',['StopStreaming',['../classNcDataStreamClientBase.html#ab6e92ed357c14fe1fba9b7a887f534d8',1,'NcDataStreamClientBase::StopStreaming()'],['../classNcDataStreamIOBase.html#a1071183a607c2c3bfecd0d11ac9d037e',1,'NcDataStreamIOBase::StopStreaming()']]],
  ['stopstreamingerror',['StopStreamingError',['../classMyGUIClient.html#a195a37de08d0b55132276af8b7eb64ab',1,'MyGUIClient']]]
];
