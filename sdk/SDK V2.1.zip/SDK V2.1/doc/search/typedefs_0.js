var searchData=
[
  ['distortionstype_5ft',['DistortionsType_t',['../classNcDataStreamOpticalParameters.html#a51bd658efc45bd6c973ac4f05d1bf1da',1,'NcDataStreamOpticalParameters']]]
];
