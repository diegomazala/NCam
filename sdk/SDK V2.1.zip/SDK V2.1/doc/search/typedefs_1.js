var searchData=
[
  ['ipport_5ft',['IpPort_t',['../classNcDataStreamIOBase.html#a04c3c1d1a70ab24fc9438b6f4c85521e',1,'NcDataStreamIOBase']]]
];
