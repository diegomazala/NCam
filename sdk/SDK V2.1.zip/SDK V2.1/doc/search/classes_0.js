var searchData=
[
  ['capabilitiespacket',['CapabilitiesPacket',['../structNcDataStreamCapabilities_1_1CapabilitiesPacket.html',1,'NcDataStreamCapabilities']]]
];
