var searchData=
[
  ['myguiclient',['MyGUIClient',['../group__MyGUIClient.html',1,'']]],
  ['mysimpleclient',['MySimpleClient',['../group__MySimpleClient.html',1,'']]],
  ['mysimpleclient_5fwin32',['MySimpleClient_win32',['../group__MySimpleClient__win32.html',1,'']]]
];
