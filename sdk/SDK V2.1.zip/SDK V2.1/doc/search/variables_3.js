var searchData=
[
  ['simpleclient',['simpleClient',['../group__MySimpleClient.html#ga366e2b0e4a567c8d2ee39e2de522a1d0',1,'simpleClient():&#160;main.cpp'],['../group__MySimpleClient__win32.html#gaa1be76911a484f086e66a21524a1e617',1,'simpleClient():&#160;main.cpp']]]
];
