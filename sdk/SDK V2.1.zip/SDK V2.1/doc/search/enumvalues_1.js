var searchData=
[
  ['cameratracking',['CameraTracking',['../classNcDataStreamBase.html#a0afdbb7bcaab33b157d075d0d51c721ba32f1fd2c4d7185bf63ed3c4d71981eb2',1,'NcDataStreamBase']]],
  ['capabilities',['Capabilities',['../classNcDataStreamBase.html#a0afdbb7bcaab33b157d075d0d51c721ba8a7d1aa9e0fef11c2eac5a887318bfba',1,'NcDataStreamBase']]],
  ['compositeimage',['CompositeImage',['../classNcDataStreamBase.html#a0afdbb7bcaab33b157d075d0d51c721ba37c925e23fef4546cf30c33d496b78e3',1,'NcDataStreamBase']]]
];
