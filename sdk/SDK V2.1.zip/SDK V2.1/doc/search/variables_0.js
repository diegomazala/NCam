var searchData=
[
  ['lpmymainwindow',['lpMyMainWindow',['../classMyGLWidget.html#ab96adee7bfe4aab3b36aa1e6cfeda320',1,'MyGLWidget']]]
];
