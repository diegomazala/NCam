var classNcDataStreamOpticalParameters =
[
    [ "OpticalParametersPacket", "structNcDataStreamOpticalParameters_1_1OpticalParametersPacket.html", "structNcDataStreamOpticalParameters_1_1OpticalParametersPacket" ],
    [ "DistortionsType_t", "classNcDataStreamOpticalParameters.html#a51bd658efc45bd6c973ac4f05d1bf1da", null ],
    [ "PacketType_t", "classNcDataStreamOpticalParameters.html#a68776d6f6c0de1b3cec269fd0a585abc", null ],
    [ "TimeCode_t", "classNcDataStreamOpticalParameters.html#a3f9e3c7306e4ef3350b0f65c356a51f6", null ],
    [ "eDistortions", "classNcDataStreamOpticalParameters.html#adf762ef24b26d47b7a7f5dc3040cf021", [
      [ "DistPinHole", "classNcDataStreamOpticalParameters.html#adf762ef24b26d47b7a7f5dc3040cf021ab42240525633f8955c796774689101c4", null ],
      [ "DistSimpleSphericalK1", "classNcDataStreamOpticalParameters.html#adf762ef24b26d47b7a7f5dc3040cf021a6f9d250d755ee076315bea9c76379007", null ],
      [ "DistSimpleSphericalK1K2", "classNcDataStreamOpticalParameters.html#adf762ef24b26d47b7a7f5dc3040cf021a5349b0a79bcc24360a929d11d1e9548e", null ],
      [ "Spherical", "classNcDataStreamOpticalParameters.html#adf762ef24b26d47b7a7f5dc3040cf021af40d1b63321ac21e478dbd35fec47641", null ],
      [ "SimpleAnamorphic", "classNcDataStreamOpticalParameters.html#adf762ef24b26d47b7a7f5dc3040cf021a89b5f846ffb70b2c3c48838f8a55bbc0", null ],
      [ "Anamorphic", "classNcDataStreamOpticalParameters.html#adf762ef24b26d47b7a7f5dc3040cf021aae6930066b591afca56201b8a8b83cea", null ],
      [ "FishEye", "classNcDataStreamOpticalParameters.html#adf762ef24b26d47b7a7f5dc3040cf021a46715c4dec85a6c81aaa5f76847b6ee8", null ],
      [ "DistBegin", "classNcDataStreamOpticalParameters.html#adf762ef24b26d47b7a7f5dc3040cf021a43f6129862936da8e534190f89e170d7", null ],
      [ "DistEnd", "classNcDataStreamOpticalParameters.html#adf762ef24b26d47b7a7f5dc3040cf021a6357758c5f1a503233dfff60c160f596", null ]
    ] ],
    [ "ePacketType", "classNcDataStreamOpticalParameters.html#a0afdbb7bcaab33b157d075d0d51c721b", [
      [ "UnknownType", "classNcDataStreamOpticalParameters.html#a0afdbb7bcaab33b157d075d0d51c721ba67818239fab08b94f69062b033206083", null ],
      [ "CameraTracking", "classNcDataStreamOpticalParameters.html#a0afdbb7bcaab33b157d075d0d51c721ba32f1fd2c4d7185bf63ed3c4d71981eb2", null ],
      [ "DepthImage", "classNcDataStreamOpticalParameters.html#a0afdbb7bcaab33b157d075d0d51c721ba01e546c0752623a6530df4e2ed6b4bde", null ],
      [ "FilmImage", "classNcDataStreamOpticalParameters.html#a0afdbb7bcaab33b157d075d0d51c721ba0f9c462d01f83492e6f57ec5a999401b", null ],
      [ "CompositeImage", "classNcDataStreamOpticalParameters.html#a0afdbb7bcaab33b157d075d0d51c721ba37c925e23fef4546cf30c33d496b78e3", null ],
      [ "DistortMap", "classNcDataStreamOpticalParameters.html#a0afdbb7bcaab33b157d075d0d51c721baee84b7390d2c945ce76fe634fe7898cc", null ],
      [ "OpticalParameters", "classNcDataStreamOpticalParameters.html#a0afdbb7bcaab33b157d075d0d51c721ba20ce37a256f82c919bb9e56b41d49cb2", null ],
      [ "Capabilities", "classNcDataStreamOpticalParameters.html#a0afdbb7bcaab33b157d075d0d51c721ba8a7d1aa9e0fef11c2eac5a887318bfba", null ],
      [ "Query", "classNcDataStreamOpticalParameters.html#a0afdbb7bcaab33b157d075d0d51c721ba05e01648e377738cb198e4d76b6035d3", null ],
      [ "TypeMask", "classNcDataStreamOpticalParameters.html#a0afdbb7bcaab33b157d075d0d51c721baa636f9e6ab84e306279d1baec53862c7", null ]
    ] ],
    [ "NcDataStreamOpticalParameters", "classNcDataStreamOpticalParameters.html#abff21089a9458c92204fd4c3240a960d", null ],
    [ "~NcDataStreamOpticalParameters", "classNcDataStreamOpticalParameters.html#a5fb724e4ec450ebfb33be2589e08c2f3", null ],
    [ "GetSizeInBytes", "classNcDataStreamOpticalParameters.html#af12721c7b6fc9a319b0b954c99984245", null ],
    [ "GetPacketType", "classNcDataStreamOpticalParameters.html#ac477fffb9d91a3dbf17e6861606ca1c4", null ],
    [ "GetData", "classNcDataStreamOpticalParameters.html#ae944010f50039a14053c83ce2ec8a3b1", null ],
    [ "GetData", "classNcDataStreamOpticalParameters.html#a4935c5f3bed81b65c489a4d255d30465", null ],
    [ "Ptr", "classNcDataStreamOpticalParameters.html#ac2fe05ae1b6fa180a0f0a6e2ccf90d75", null ],
    [ "Ptr", "classNcDataStreamOpticalParameters.html#ab2d570e913107325e4ee1d4f13ac2757", null ],
    [ "ToPtr", "classNcDataStreamOpticalParameters.html#a0021c559ec3d619d77d42b819dab3783", null ],
    [ "ToPtr", "classNcDataStreamOpticalParameters.html#a5fe48ffe08f44ddadeba96cb7d021bc7", null ],
    [ "FromPtr", "classNcDataStreamOpticalParameters.html#ae30c6570e2138e8fda5466a38ffe28d7", null ],
    [ "FromPtr", "classNcDataStreamOpticalParameters.html#a925ec1c2b3af76daa5e659089836cc53", null ],
    [ "OnDecodingFromPtrError", "classNcDataStreamOpticalParameters.html#ac3173d3bb28fa8dbf4ec29201f279099", null ]
];