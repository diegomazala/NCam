var structNcDataStreamCamTrack_1_1RigidTransfoPacket =
[
    [ "mRotation", "structNcDataStreamCamTrack_1_1RigidTransfoPacket.html#a38d9e554b6797313f8dd79ef65a59944", null ],
    [ "mTranslation", "structNcDataStreamCamTrack_1_1RigidTransfoPacket.html#a208401e51cf487a0886966ed3acf4028", null ]
];