var structNcDataStreamCamTrack_1_1LensEncoderPacket =
[
    [ "mNormalized", "structNcDataStreamCamTrack_1_1LensEncoderPacket.html#a934655cccc02f1f43201f86860e701f0", null ],
    [ "mMappedValue", "structNcDataStreamCamTrack_1_1LensEncoderPacket.html#a2b7d940756902b59e8c4028de10a481b", null ]
];