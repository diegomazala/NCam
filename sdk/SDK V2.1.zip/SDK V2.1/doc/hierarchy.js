var hierarchy =
[
    [ "NcDataStreamCapabilities::CapabilitiesPacket", "structNcDataStreamCapabilities_1_1CapabilitiesPacket.html", null ],
    [ "GLWidget", "classGLWidget.html", null ],
    [ "NcDataStreamCamTrack::LensEncoderPacket", "structNcDataStreamCamTrack_1_1LensEncoderPacket.html", null ],
    [ "MyDistortMapToTexture", "classMyDistortMapToTexture.html", null ],
    [ "MyTrackBall", "classMyTrackBall.html", null ],
    [ "NcDataBufferSwap< T, NbBuffers >", "classNcDataBufferSwap.html", null ],
    [ "NcDataBufferSwap< Packets_t >", "classNcDataBufferSwap.html", null ],
    [ "NcDataStreamBase", "classNcDataStreamBase.html", [
      [ "NcDataStreamCamTrack", "classNcDataStreamCamTrack.html", null ],
      [ "NcDataStreamCapabilities", "classNcDataStreamCapabilities.html", null ],
      [ "NcDataStreamImage", "classNcDataStreamImage.html", [
        [ "NcDataStreamCompositeImage", "classNcDataStreamCompositeImage.html", null ],
        [ "NcDataStreamDepthImage", "classNcDataStreamDepthImage.html", null ],
        [ "NcDataStreamDistortMap", "classNcDataStreamDistortMap.html", null ],
        [ "NcDataStreamFilmImage", "classNcDataStreamFilmImage.html", null ]
      ] ],
      [ "NcDataStreamOpticalParameters", "classNcDataStreamOpticalParameters.html", null ],
      [ "NcDataStreamQuery", "classNcDataStreamQuery.html", null ]
    ] ],
    [ "NcDataStreamIOBase", "classNcDataStreamIOBase.html", [
      [ "NcDataStreamClientBase", "classNcDataStreamClientBase.html", [
        [ "MyClient", "classMyClient.html", null ],
        [ "MyGUIClient", "classMyGUIClient.html", null ],
        [ "MySimpleClient", "classMySimpleClient.html", null ]
      ] ]
    ] ],
    [ "NcResourceReader< ProtectedResource, lMode >", "classNcResourceReader.html", null ],
    [ "NcResourceWriter< ProtectedResource, lMode >", "classNcResourceWriter.html", null ],
    [ "NcThreadSafeResource< ProtectedResource, lMode >", "classNcThreadSafeResource.html", null ],
    [ "NcThreadSafeResource< bool >", "classNcThreadSafeResource.html", null ],
    [ "NcThreadSafeResource< int, QReadWriteLock::NonRecursive >", "classNcThreadSafeResource.html", null ],
    [ "NcTrackBall", "classNcTrackBall.html", null ],
    [ "NcDataStreamImage::NcTrackStreamImageHeader", "structNcDataStreamImage_1_1NcTrackStreamImageHeader.html", null ],
    [ "NcDataStreamOpticalParameters::OpticalParametersPacket", "structNcDataStreamOpticalParameters_1_1OpticalParametersPacket.html", null ],
    [ "QGLFunctions", null, [
      [ "MySimpleCompositor", "classMySimpleCompositor.html", null ]
    ] ],
    [ "QGLWidget", null, [
      [ "MyGLWidget", "classMyGLWidget.html", null ]
    ] ],
    [ "QMainWindow", null, [
      [ "MyMainWindow", "classMyMainWindow.html", null ]
    ] ],
    [ "QThread", null, [
      [ "MyGUIClient", "classMyGUIClient.html", null ]
    ] ],
    [ "NcDataStreamQuery::QueryPacket", "structNcDataStreamQuery_1_1QueryPacket.html", null ],
    [ "NcDataStreamCamTrack::RigidTransfoPacket", "structNcDataStreamCamTrack_1_1RigidTransfoPacket.html", null ],
    [ "NcDataStreamCamTrack::TrackingPacket", "structNcDataStreamCamTrack_1_1TrackingPacket.html", null ],
    [ "ProtectedResource", null, null ]
];