var classNcDataStreamDepthImage =
[
    [ "PacketType_t", "classNcDataStreamDepthImage.html#a68776d6f6c0de1b3cec269fd0a585abc", null ],
    [ "TimeCode_t", "classNcDataStreamDepthImage.html#a3f9e3c7306e4ef3350b0f65c356a51f6", null ],
    [ "Channels", "classNcDataStreamDepthImage.html#a8769b19ae80f367f3edc782190425542", [
      [ "UnknownChannels", "classNcDataStreamDepthImage.html#a8769b19ae80f367f3edc782190425542af9fb06a398f22b216bb6df9135706b2e", null ],
      [ "Nc1Channel", "classNcDataStreamDepthImage.html#a8769b19ae80f367f3edc782190425542ab4c94ece30f04e329b7783ca0bbd62f2", null ],
      [ "Nc2Channels", "classNcDataStreamDepthImage.html#a8769b19ae80f367f3edc782190425542a1e91381ebf1d8415ae4f3deb4a125ad5", null ],
      [ "NcRGB", "classNcDataStreamDepthImage.html#a8769b19ae80f367f3edc782190425542a260a41966e043c528775d45cb5b0b904", null ],
      [ "NcRGBD", "classNcDataStreamDepthImage.html#a8769b19ae80f367f3edc782190425542a8abc384b1334959383fe17a98a052e2f", null ]
    ] ],
    [ "Depth", "classNcDataStreamDepthImage.html#abbf986e42def91eca4c9088f0a51a6a8", [
      [ "UnknownDepth", "classNcDataStreamDepthImage.html#abbf986e42def91eca4c9088f0a51a6a8ac3a66c461338595b064cb5a88f7689ce", null ],
      [ "OneBytePerPixel", "classNcDataStreamDepthImage.html#abbf986e42def91eca4c9088f0a51a6a8a698e23d373a1c26f87705d2753128769", null ],
      [ "OneFloatPerPixel", "classNcDataStreamDepthImage.html#abbf986e42def91eca4c9088f0a51a6a8a691a18fbe7d64c2889f17a29b9abe2f3", null ]
    ] ],
    [ "ePacketType", "classNcDataStreamDepthImage.html#a0afdbb7bcaab33b157d075d0d51c721b", [
      [ "UnknownType", "classNcDataStreamDepthImage.html#a0afdbb7bcaab33b157d075d0d51c721ba67818239fab08b94f69062b033206083", null ],
      [ "CameraTracking", "classNcDataStreamDepthImage.html#a0afdbb7bcaab33b157d075d0d51c721ba32f1fd2c4d7185bf63ed3c4d71981eb2", null ],
      [ "DepthImage", "classNcDataStreamDepthImage.html#a0afdbb7bcaab33b157d075d0d51c721ba01e546c0752623a6530df4e2ed6b4bde", null ],
      [ "FilmImage", "classNcDataStreamDepthImage.html#a0afdbb7bcaab33b157d075d0d51c721ba0f9c462d01f83492e6f57ec5a999401b", null ],
      [ "CompositeImage", "classNcDataStreamDepthImage.html#a0afdbb7bcaab33b157d075d0d51c721ba37c925e23fef4546cf30c33d496b78e3", null ],
      [ "DistortMap", "classNcDataStreamDepthImage.html#a0afdbb7bcaab33b157d075d0d51c721baee84b7390d2c945ce76fe634fe7898cc", null ],
      [ "OpticalParameters", "classNcDataStreamDepthImage.html#a0afdbb7bcaab33b157d075d0d51c721ba20ce37a256f82c919bb9e56b41d49cb2", null ],
      [ "Capabilities", "classNcDataStreamDepthImage.html#a0afdbb7bcaab33b157d075d0d51c721ba8a7d1aa9e0fef11c2eac5a887318bfba", null ],
      [ "Query", "classNcDataStreamDepthImage.html#a0afdbb7bcaab33b157d075d0d51c721ba05e01648e377738cb198e4d76b6035d3", null ],
      [ "TypeMask", "classNcDataStreamDepthImage.html#a0afdbb7bcaab33b157d075d0d51c721baa636f9e6ab84e306279d1baec53862c7", null ]
    ] ],
    [ "NcDataStreamDepthImage", "classNcDataStreamDepthImage.html#a03edd9c99cefc440c9db3b0ad963c2a1", null ],
    [ "~NcDataStreamDepthImage", "classNcDataStreamDepthImage.html#a5f6fb63c454d7a21b1873abd96411af5", null ],
    [ "GetSizeInBytes", "classNcDataStreamDepthImage.html#ac146384e1c350c7942c5c8ec8abd00c9", null ],
    [ "GetPacketType", "classNcDataStreamDepthImage.html#ab0e9776c76d23735a8c5fa66d01b520e", null ],
    [ "FromPtr", "classNcDataStreamDepthImage.html#ab393b31f0dbb5de349063e3a0577073b", null ],
    [ "FromPtr", "classNcDataStreamDepthImage.html#a925ec1c2b3af76daa5e659089836cc53", null ],
    [ "SetTimeCode", "classNcDataStreamDepthImage.html#a66a32752a695ddb9b53b53ff88ee974b", null ],
    [ "SetSize", "classNcDataStreamDepthImage.html#a4e9390e82abbeaf6d096e46a9a97b60d", null ],
    [ "GetSize", "classNcDataStreamDepthImage.html#ae257b3fa47b10de4b8473cb3ec8869b6", null ],
    [ "GetWidth", "classNcDataStreamDepthImage.html#a0d71f82f2273f461746dfc8bb130f248", null ],
    [ "GetHeight", "classNcDataStreamDepthImage.html#a02fe6f639333520673f373fd7a2b7ebf", null ],
    [ "GetChannels", "classNcDataStreamDepthImage.html#a4bcdb0e5035ce29fe0e92d9053b70b62", null ],
    [ "GetDepth", "classNcDataStreamDepthImage.html#a3be536fa0c0425b5dfeb6be518f38cc2", null ],
    [ "GetImagePtr", "classNcDataStreamDepthImage.html#aa0765a2fe5acca3e0a1b061cc54f720b", null ],
    [ "GetImagePtr", "classNcDataStreamDepthImage.html#a021b32bdd865b641ce8e842ba7b6879a", null ],
    [ "GetImageSizeInBytes", "classNcDataStreamDepthImage.html#a4b68ea71e07a919235493ac87cea7013", null ],
    [ "Ptr", "classNcDataStreamDepthImage.html#a8cc1808998430fc03d438b27cdbf768a", null ],
    [ "Ptr", "classNcDataStreamDepthImage.html#aa1f26e02048676d452ba80f7aaa2dfff", null ],
    [ "GetHeaderInBytes", "classNcDataStreamDepthImage.html#a1a0c0df35e7acd196c0ebc885ec8d371", null ],
    [ "UpdateImageSize", "classNcDataStreamDepthImage.html#a6fe18aa0dfd17b1f9a77055565b45257", null ],
    [ "ToPtr", "classNcDataStreamDepthImage.html#a0021c559ec3d619d77d42b819dab3783", null ],
    [ "ToPtr", "classNcDataStreamDepthImage.html#a5fe48ffe08f44ddadeba96cb7d021bc7", null ],
    [ "OnDecodingFromPtrError", "classNcDataStreamDepthImage.html#ac3173d3bb28fa8dbf4ec29201f279099", null ],
    [ "mData", "classNcDataStreamDepthImage.html#ac9a886f826600bfb7777a011861eb660", null ],
    [ "mPreviousImageSizeInBytes", "classNcDataStreamDepthImage.html#a44bb2531558da33e23f62ebd16ca16e4", null ]
];