var classNcDataStreamBase =
[
    [ "PacketType_t", "classNcDataStreamBase.html#a68776d6f6c0de1b3cec269fd0a585abc", null ],
    [ "TimeCode_t", "classNcDataStreamBase.html#a3f9e3c7306e4ef3350b0f65c356a51f6", null ],
    [ "ePacketType", "classNcDataStreamBase.html#a0afdbb7bcaab33b157d075d0d51c721b", [
      [ "UnknownType", "classNcDataStreamBase.html#a0afdbb7bcaab33b157d075d0d51c721ba67818239fab08b94f69062b033206083", null ],
      [ "CameraTracking", "classNcDataStreamBase.html#a0afdbb7bcaab33b157d075d0d51c721ba32f1fd2c4d7185bf63ed3c4d71981eb2", null ],
      [ "DepthImage", "classNcDataStreamBase.html#a0afdbb7bcaab33b157d075d0d51c721ba01e546c0752623a6530df4e2ed6b4bde", null ],
      [ "FilmImage", "classNcDataStreamBase.html#a0afdbb7bcaab33b157d075d0d51c721ba0f9c462d01f83492e6f57ec5a999401b", null ],
      [ "CompositeImage", "classNcDataStreamBase.html#a0afdbb7bcaab33b157d075d0d51c721ba37c925e23fef4546cf30c33d496b78e3", null ],
      [ "DistortMap", "classNcDataStreamBase.html#a0afdbb7bcaab33b157d075d0d51c721baee84b7390d2c945ce76fe634fe7898cc", null ],
      [ "OpticalParameters", "classNcDataStreamBase.html#a0afdbb7bcaab33b157d075d0d51c721ba20ce37a256f82c919bb9e56b41d49cb2", null ],
      [ "Capabilities", "classNcDataStreamBase.html#a0afdbb7bcaab33b157d075d0d51c721ba8a7d1aa9e0fef11c2eac5a887318bfba", null ],
      [ "Query", "classNcDataStreamBase.html#a0afdbb7bcaab33b157d075d0d51c721ba05e01648e377738cb198e4d76b6035d3", null ],
      [ "TypeMask", "classNcDataStreamBase.html#a0afdbb7bcaab33b157d075d0d51c721baa636f9e6ab84e306279d1baec53862c7", null ]
    ] ],
    [ "~NcDataStreamBase", "classNcDataStreamBase.html#ac27380cd4cb0cbfa63b2eef1469359d4", null ],
    [ "NcDataStreamBase", "classNcDataStreamBase.html#a58d9f08392b0c35300c32e6798934f2e", null ],
    [ "ToPtr", "classNcDataStreamBase.html#a0021c559ec3d619d77d42b819dab3783", null ],
    [ "ToPtr", "classNcDataStreamBase.html#a5fe48ffe08f44ddadeba96cb7d021bc7", null ],
    [ "FromPtr", "classNcDataStreamBase.html#ae30c6570e2138e8fda5466a38ffe28d7", null ],
    [ "FromPtr", "classNcDataStreamBase.html#a925ec1c2b3af76daa5e659089836cc53", null ],
    [ "GetSizeInBytes", "classNcDataStreamBase.html#a0692805f5d845090c944d97ce32191df", null ],
    [ "GetPacketType", "classNcDataStreamBase.html#adf19205a52c78d015cb5db73992f67eb", null ],
    [ "OnDecodingFromPtrError", "classNcDataStreamBase.html#ac3173d3bb28fa8dbf4ec29201f279099", null ],
    [ "Ptr", "classNcDataStreamBase.html#ae76b06904f85611dfc57395fc93722dd", null ],
    [ "Ptr", "classNcDataStreamBase.html#ad5f63dca8db523a7e9d0273743aeb2d6", null ]
];