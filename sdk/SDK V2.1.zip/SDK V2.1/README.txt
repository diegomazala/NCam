To compile the examples (apart from the one called MySimpleClient_win32), you will need to install qt4.8.3.
For your convenience, all examples have been already compiled and placed in the bin/ directory.
To execute any compiled program, you will need the dll called LibNcamDataStreaming.dll in 32 bits or 64 bits following the configuration you have chosen.
