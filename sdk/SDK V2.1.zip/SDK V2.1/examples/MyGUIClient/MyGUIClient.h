/*
*  Copyright (c) 2012-2014 Ncam Technologies Ltd. All rights reserved.
*  Unpublished - rights reserved under the copyright laws of the
*  United States. Use of a copyright notice is precautionary only
*  and does not imply publication or disclosure.
*  This software contains confidential information and trade secrets
*  of Ncam Technologies Limited. Use, disclosure, or reproduction
*  is prohibited without the prior express written permission of
*  Ncam Technologies Limited.
*/

#ifndef NCDATASTREAMCLIENT_H
#define NCDATASTREAMCLIENT_H
/** \addtogroup MyGUIClient
 *  @{
 */
#include <QThread>
#include <QTcpSocket>
#include <NcDataStreamClientBase.h>
#include <NcThreadSafeTools.h>
///
/// \brief The MyGUIClient reimplements NcDataStreamClientBase.
///
class MyGUIClient: public QThread, public NcDataStreamClientBase
{
    Q_OBJECT
public:
    MyGUIClient();
    virtual ~MyGUIClient();
    //Here are all the methods we need to redefine.
    virtual bool IsConnected() const;

    void Exec();
    void StopExec();

    bool IsNewDataToMap();
    bool WaitForNewDataToMap(unsigned long luiTime);
    Packets_t& MapData(bool &lIsASuccess, bool lWaitForNewData, unsigned long luiTime);
    void UnMapData();

signals:
    void StartStreamingError(QString lDescription);
    void StopStreamingError(QString lDescription);
    void DoStreamingError(QString lDescription);

protected:
    //Error Handling
    virtual void OnStartStreamingError(const std::string& lErrorDecription = std::string());
    virtual void OnStopStreamingError(const std::string& lErrorDecription = std::string());
    virtual void OnDoStreamingError(const std::string& lErrorDecription = std::string());

    // This is the method called in the thread
    virtual void run();

    virtual bool InternalOpen();
    virtual bool InternalClose();

    virtual ssize_t InternalRead(uint8_t *data, const size_t& maxlen);
    virtual ssize_t InternalWrite(const uint8_t *data, const size_t& maxlen);

    virtual Packets_t& MapPackets(bool& lSuccess) ;
    virtual void UnmapPackets();
private:
    QTcpSocket* mpTcpSocket;

    //Should be protected by a mutex
    NcThreadSafeResource<bool> mbThreadShouldRun;
    NcDataBufferSwap<Packets_t> mDataBufferSwap;
};
/** @}*/

#endif // NCDATASTREAMCLIENT_H
