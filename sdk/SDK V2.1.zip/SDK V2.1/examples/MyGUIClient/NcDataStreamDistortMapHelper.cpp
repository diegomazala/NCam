/*
*  Copyright (c) 2012-2014 Ncam Technologies Ltd. All rights reserved.
*  Unpublished - rights reserved under the copyright laws of the
*  United States. Use of a copyright notice is precautionary only
*  and does not imply publication or disclosure.
*  This software contains confidential information and trade secrets
*  of Ncam Technologies Limited. Use, disclosure, or reproduction
*  is prohibited without the prior express written permission of
*  Ncam Technologies Limited.
*/

#include <NcDataStreamDistortMapHelper.h>
#include <QGLShaderProgram>
#include <QGLFramebufferObject>
#include <iostream>

// Some GL3 define missing on windows platforms...
#ifndef GL_RG32F
#define GL_RG32F 0x8230
#endif

#ifndef GL_RG
#define GL_RG 0x8227
#endif

MyDistortMapToTexture::MyDistortMapToTexture():
    mDistortTexId(0)
{

}

uint32_t MyDistortMapToTexture::texture() const
{
    return mDistortTexId;
}

bool MyDistortMapToTexture::UpdateTextureFromDistortMap(const NcDataStreamDistortMap& lpNcDataStreamDistortMap)
{

    GLint lInternalFormat = 0;
    GLenum lFormat = 0;
    GLenum lType = 0;
    if (mDistortTexId == 0)
    {
        glGenTextures(1,&mDistortTexId);
        glBindTexture(GL_TEXTURE_2D, mDistortTexId);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S, GL_CLAMP);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glPixelStorei(GL_UNPACK_ALIGNMENT,1);
    }
    else
    {
        glBindTexture(GL_TEXTURE_2D, mDistortTexId);
    }


    if (NcDataStreamDistortMap::Nc2Channels == lpNcDataStreamDistortMap.GetChannels() && NcDataStreamDistortMap::OneFloatPerPixel == lpNcDataStreamDistortMap.GetDepth())
    {
        lInternalFormat = GL_RG32F;
        lFormat = GL_RG;
        lType = GL_FLOAT;
    }
    else
    {
        qWarning() << "NcDataStreamDistortMap -> the image format is not implemented Yet "<< __FUNCTION__ << __LINE__;
        return false;
    }
    glTexImage2D(GL_TEXTURE_2D, 0, lInternalFormat, lpNcDataStreamDistortMap.GetWidth(), lpNcDataStreamDistortMap.GetHeight(), 0, lFormat, lType, (const GLvoid*)lpNcDataStreamDistortMap.GetImagePtr()); /* Texture specification */
    glBindTexture(GL_TEXTURE_2D, 0);
    return true;
}

// source code of the fragment shader that distorts the cg generated image to make it fit with the filmcamera's lens distortions.
// DistortUScale and DistortUScale (resp. DistortVScale and DistortVScale) are used to only use the part of the texture that is correclty interpolated
const char* lFragmentShaderSrc =
        "uniform sampler2D CGTex;\n"
        "uniform sampler2D DistortTex;\n"
        "uniform float DistortUScale;\n"
        "uniform float DistortUOffset;\n"
        "uniform float DistortVScale;\n"
        "uniform float DistortVOffset;\n"
        "void main()\n"
        "{\n"
        "    // When getting the distorted parameters, the distortion map orig is top left; opengl orig is bottom left\n"
        "    vec2 lTexCoordImageOrig = vec2(gl_TexCoord[0].s, gl_TexCoord[0].t);\n"
        "    lTexCoordImageOrig.x = lTexCoordImageOrig.x*DistortUScale + DistortUOffset;\n"
        "    lTexCoordImageOrig.y = lTexCoordImageOrig.y*DistortVScale + DistortVOffset;\n"
        "    vec2 lTexCoord = texture2D(DistortTex,lTexCoordImageOrig).rg;\n"
        "    lTexCoord.y = 1.0 - lTexCoord.y;\n"
        "    vec4 CGTex = texture2D(CGTex,lTexCoord);\n"
        "    gl_FragColor = vec4(CGTex.rgb,1.0);\n"
        "}\n";


MySimpleCompositor::MySimpleCompositor():
    QGLFunctions(),
    mMyDistortMapToTexture(),
    mpShaderProgram(nullptr),
    mpCGFramebufferObject(nullptr),
    mViewportXOrig(0),
    mViewportYOrig(0),
    mViewportWidth(0),
    mViewportHeight(0),
    mUndistortMapWidth(0),
    mUndistortMapHeight(0),
    mOverSampleFactor(2)
{

}

MySimpleCompositor::~MySimpleCompositor()
{
    DeleteShader();
    DeleteFBO();
}
void MySimpleCompositor::InitializeGL()
{
    initializeGLFunctions();
    CreateShader();
}

void MySimpleCompositor::BeginRenderCGToTexture(const NcDataStreamOpticalParameters::OpticalParametersPacket & lOpticalPacket, const NcDataStreamCamTrack::TrackingPacket &lTrackingPacket)
{
    CreateOrUpdateFBO();
    mpCGFramebufferObject->bind();
    glViewport(0,0,mViewportWidth*mOverSampleFactor,mViewportHeight*mOverSampleFactor);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    GLdouble Projection[16];
    GLdouble ModelView[16];
    NcDataStreamOpticalParametersHelper::GetProjectionMatrix(lOpticalPacket,Projection);
    NcDataStreamCamHelper::ToOpenGLModelView(lTrackingPacket,ModelView);

    glMatrixMode(GL_PROJECTION);
    glLoadMatrixd(Projection);

    glMatrixMode(GL_MODELVIEW);
    glLoadMatrixd(ModelView);
}

void MySimpleCompositor::EndRenderCGToTexture()
{
    mpCGFramebufferObject->release();
}

void MySimpleCompositor::DoCompositing(const NcDataStreamDistortMap& lpNcDataStreamDistortMap)
{
    if (UpdateDistortMap(lpNcDataStreamDistortMap))
    {
        mpShaderProgram->bind();
        mpShaderProgram->setUniformValue("DistortUScale", (mUndistortMapWidth-1.0f)/mUndistortMapWidth);
        mpShaderProgram->setUniformValue("DistortUOffset", 0.5f/mUndistortMapWidth);
        mpShaderProgram->setUniformValue("DistortVScale", (mUndistortMapHeight-1.0f)/mUndistortMapHeight);
        mpShaderProgram->setUniformValue("DistortVOffset", 0.5f/mUndistortMapHeight);
        mpShaderProgram->setUniformValue("CGTex", 0);
        mpShaderProgram->setUniformValue("DistortTex", 1);

        glViewport(mViewportXOrig,mViewportYOrig,mViewportWidth,mViewportHeight);
        glClearColor(0.9f,0.9f,0.9f,1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        glDisable(GL_DEPTH_TEST);
        glEnable(GL_TEXTURE_2D);

        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(0.0,1.0,1.0,0.0,0.0,1.0);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, mpCGFramebufferObject->texture());
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, mMyDistortMapToTexture.texture());
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

        //Render Unit Quad
        glColor4f(1.0f,1.0f,1.0f,1.0f);
        glBegin(GL_QUADS);
        {
            glTexCoord2d(0.0, 0.0);
            glVertex2d(0.0,0.0);
            glTexCoord2d(0.0, 1.0);
            glVertex2d(0.0,1.0);
            glTexCoord2d(1.0, 1.0);
            glVertex2d(1.0,1.0);
            glTexCoord2d(1.0, 0.0);
            glVertex2d(1.0,0.0);
        }
        glEnd();

        glBindTexture(GL_TEXTURE_2D, 0);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, 0);

        mpShaderProgram->release();

        glDisable(GL_TEXTURE_2D);
        glEnable(GL_DEPTH_TEST);
    }
}

void MySimpleCompositor::SetViewPort(uint32_t lXOrig, uint32_t lYOrig, uint32_t lWidth, uint32_t lHeight)
{
    mViewportXOrig = lXOrig;
    mViewportYOrig = lYOrig;
    mViewportWidth = lWidth;
    mViewportHeight = lHeight;
}

void MySimpleCompositor::SetDistortMapResolution(uint32_t lWidth, uint32_t lHeight)
{
    mUndistortMapWidth = lWidth;
    mUndistortMapHeight = lHeight;
}

bool MySimpleCompositor::CreateShader()
{
    if (nullptr == mpShaderProgram)
    {
        mpShaderProgram = new QGLShaderProgram();
        mpShaderProgram->addShaderFromSourceCode(QGLShader::Fragment,lFragmentShaderSrc);
        if (false == mpShaderProgram->link())
        {
            qWarning() << "MySimpleCompositor \n"<< mpShaderProgram->log();
        }
        mpShaderProgram->bind();
        mpShaderProgram->setUniformValue("CGTex", 0);
        mpShaderProgram->setUniformValue("DistortTex", 1);
        mpShaderProgram->release();
        return mpShaderProgram->link();
    }
    return false;
}

bool MySimpleCompositor::DeleteShader()
{
    if (mpShaderProgram)
    {
        delete(mpShaderProgram);
        mpShaderProgram = nullptr;
        return true;
    }
    return false;
}

bool MySimpleCompositor::CreateOrUpdateFBO()
{
    QGLFramebufferObjectFormat lFormat;
    lFormat.setSamples(0);
    lFormat.setAttachment(QGLFramebufferObject::CombinedDepthStencil);

    if (nullptr == mpCGFramebufferObject)
    {
        mpCGFramebufferObject = new QGLFramebufferObject(
                    QSize(mViewportWidth*mOverSampleFactor,mViewportHeight*mOverSampleFactor),
                    lFormat);
        return true;
    }
    else
    {
        if (mpCGFramebufferObject->size() !=QSize(mViewportWidth*mOverSampleFactor,mViewportHeight*mOverSampleFactor))
        {
            DeleteFBO();
            mpCGFramebufferObject = new QGLFramebufferObject(
                        QSize(mViewportWidth*mOverSampleFactor,mViewportHeight*mOverSampleFactor),
                        lFormat);
            return true;
        }
    }
    return false;
}

bool MySimpleCompositor::DeleteFBO()
{
    if (nullptr != mpCGFramebufferObject)
    {
        delete(mpCGFramebufferObject);
        mpCGFramebufferObject = nullptr;
        return true;
    }
    return false;
}

bool MySimpleCompositor::UpdateDistortMap(const NcDataStreamDistortMap& lpNcDataStreamDistortMap)
{
    bool lResult = false;
    lResult = mMyDistortMapToTexture.UpdateTextureFromDistortMap(lpNcDataStreamDistortMap);
    SetDistortMapResolution(lpNcDataStreamDistortMap.GetWidth(), lpNcDataStreamDistortMap.GetHeight());
    return lResult;
}

void MySimpleCompositor::SetAspectRatioViewport(int AvailableWidth, int AvailableHeight, double dAspectRatio)
{
    double dAspect = AvailableWidth/(double)(AvailableHeight ? AvailableHeight : 1);
    if (dAspect>dAspectRatio)
    {
        int width = (int)(AvailableHeight*dAspectRatio);
        int Diff = AvailableWidth - width;
        mViewportXOrig = Diff/2;
        mViewportYOrig = 0;
        mViewportWidth = width;
        mViewportHeight = AvailableHeight;
    }
    else
    {
        int height = (int)(AvailableWidth * 1.0/dAspectRatio);
        int Diff = AvailableHeight - height;

        mViewportXOrig = 0;
        mViewportYOrig = Diff/2;
        mViewportWidth = AvailableWidth;
        mViewportHeight = height;
    }
}
