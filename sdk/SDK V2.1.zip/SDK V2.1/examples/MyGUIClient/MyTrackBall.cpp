/*
*  Copyright (c) 2012 Ncam. All rights reserved.
*  Unpublished - rights reserved under the copyright laws of the
*  UK. Use of a copyright notice is precautionary only
*  and does not imply publication or disclosure.
*  This software contains confidential information and trade secrets
*  of Ncam Solutions Limited. Use, disclosure, or reproduction
*  is prohibited without the prior express written permission of
*  Ncam Solutions Limited.
*/

#include "MyTrackBall.h"

MyTrackBall::MyTrackBall(TrackMode mode):
    mAngularVelocity(0),
    mbPaused(false),
    mbPressed(false),
    mCurrentMode(mode)
 {
    mAxis = QVector3D(0, 1, 0);
    mRotation = QQuaternion();
    mLastTime = QTime::currentTime();
}

MyTrackBall::MyTrackBall(double angularVelocity, const QVector3D& axis, TrackMode mode):
    mAxis(axis),
    mAngularVelocity(angularVelocity),
    mbPaused(false),
    mbPressed(false),
    mCurrentMode(mode)
 {
    mRotation = QQuaternion();
    mLastTime = QTime::currentTime();
}

void MyTrackBall::Push(const QPointF& p, const QQuaternion &)
 {
    mRotation = GetRotation();
    mbPressed = true;
    mLastTime = QTime::currentTime();
    mLastPos = p;
    mAngularVelocity = 0.0f;
}

void MyTrackBall::Move(const QPointF& p, const QQuaternion &transformation)
 {
    if (!mbPressed)
        return;

    QTime currentTime = QTime::currentTime();
    int msecs = mLastTime.msecsTo(currentTime);
    if (msecs <= 20)
        return;

    switch (mCurrentMode)  {
    case Plane:
         {
            QLineF delta(mLastPos, p);
            mAngularVelocity = 180*delta.length() / (3.14*msecs);
            mAxis = QVector3D(-delta.dy(), delta.dx(), 0.0f).normalized();
            mAxis = transformation.rotatedVector(mAxis);
            mRotation = QQuaternion::fromAxisAndAngle(mAxis, 180 /3.14 * delta.length()) * mRotation;
        }
        break;
    case Sphere:
         {
            QVector3D lastPos3D = QVector3D(mLastPos.x(), mLastPos.y(), 0.0f);
            float sqrZ = 1 - QVector3D::dotProduct(lastPos3D, lastPos3D);
            if (sqrZ > 0)
                lastPos3D.setZ(sqrt(sqrZ));
            else
                lastPos3D.normalize();

            QVector3D currentPos3D = QVector3D(p.x(), p.y(), 0.0f);
            sqrZ = 1 - QVector3D::dotProduct(currentPos3D, currentPos3D);
            if (sqrZ > 0)
                currentPos3D.setZ(sqrt(sqrZ));
            else
                currentPos3D.normalize();

            mAxis = QVector3D::crossProduct(lastPos3D, currentPos3D);
            float angle = 180 / 3.14 * asin(sqrt(QVector3D::dotProduct(mAxis, mAxis)));

            mAngularVelocity = angle / msecs;
            mAxis.normalize();
            mAxis = transformation.rotatedVector(mAxis);
            mRotation = QQuaternion::fromAxisAndAngle(mAxis, angle) * mRotation;
        }
        break;
    }

    mLastPos = p;
    mLastTime = currentTime;
}

void MyTrackBall::Release(const QPointF& p, const QQuaternion &transformation)
 {
    // Calling move() causes the rotation to stop if the framerate is too low.
    Move(p, transformation);
    mbPressed = false;
}

void MyTrackBall::StartClock()
 {
    mLastTime = QTime::currentTime();
    mbPaused = false;
}

void MyTrackBall::StopClock()
 {
    mRotation = GetRotation();
    mbPaused = true;
}

QQuaternion MyTrackBall::GetRotation() const
 {
    if (mbPaused || mbPressed)
        return mRotation;

    QTime currentTime = QTime::currentTime();
    float angle = mAngularVelocity * mLastTime.msecsTo(currentTime);
    return QQuaternion::fromAxisAndAngle(mAxis, angle) * mRotation;
}
