/*
*  Copyright (c) 2012 Ncam. All rights reserved.
*  Unpublished - rights reserved under the copyright laws of the
*  UK. Use of a copyright notice is precautionary only
*  and does not imply publication or disclosure.
*  This software contains confidential information and trade secrets
*  of Ncam Solutions Limited. Use, disclosure, or reproduction
*  is prohibited without the prior express written permission of
*  Ncam Solutions Limited.
*/
#ifndef GLWIDGET_H
#define GLWIDGET_H
/** \addtogroup MyGUIClient
 *  @{
 */
#include <QtGui>
#include <QGLWidget>
#include "MyTrackBall.h"
#include <NcDataStreaming.h>
#include <NcDataStreamDistortMapHelper.h>
class MyMainWindow;

/// \class GLWidget
/// \brief Defines a widget that uses opengl and displays the result.

class MyGLWidget : public QGLWidget
{
    Q_OBJECT
public:

    /// \brief Constructor.
    /// \param parent is the parent widget.
    MyGLWidget(MyMainWindow *parent = 0);

    /// \brief Destructor.
    ~MyGLWidget();

    /// \brief Holds the recommended minimum size for the widget.
    QSize minimumSizeHint() const;

    /// \brief Holds the recommended size for the widget.
    QSize sizeHint() const;

    NcDataStreamBase::PacketType_t& GetPacketsActivated();
    const NcDataStreamBase::PacketType_t& GetPacketsActivated() const;

    NcDataStreamCamTrack& GetCamTrack();
    const NcDataStreamCamTrack& GetCamTrack() const;

    NcDataStreamOpticalParameters& GetOpticalParams();
    const NcDataStreamOpticalParameters& GetOpticalParams() const;

    NcDataStreamDistortMap& GetDistortMap();
    const NcDataStreamDistortMap& GetDistortMap() const;

    void SetRenderFromCam(bool lValue);



protected:

    virtual void timerEvent(QTimerEvent* event);
    /// \brief This method is called once before the first call to paintGL() or resizeGL(), and then once whenever the widget has been assigned a new QGLContext.
    /// It is used to define the OpenGL State.
    void initializeGL();

    /// \brief This method is called whenever the widget needs to be painted.
    /// This method does the rendering.
    void paintGL();

    /// \brief This method is called whenever the widget has been resized
    /// \param width is the new width of the widget;
    /// \param height is the new height of the widget;
    void resizeGL(int width, int height);

    /// \brief Called when there is a mouse Press Event.
    void mousePressEvent(QMouseEvent *event);
    /// \brief Called when there is a mouse Move Event.
    void mouseMoveEvent(QMouseEvent *event);
    /// \brief Called when there is a mouse Press Release Event.
    void mouseReleaseEvent(QMouseEvent *event);
    /// \brief Called when there is a mouse Wheel Event.
    void wheelEvent(QWheelEvent *event);
    /// \brief Convert PixelPos \f$\in\f$ Screen Coordinates to ViewPos \f$\in [-1,1] \times [-1,1]\f$
    inline QPointF PixelPosToViewPos(const QPoint& p)const
    {
        return QPointF(2.0 * float(p.x()) / width() - 1.0,
                       1.0 - 2.0 * float(p.y()) / height());
    }

    /// \brief Renders a simple y = 0 grid.
    /// Lines are spaced at 1 meter.
    void RenderGrid();

    MySimpleCompositor mMySimpleCompositor;
    MyTrackBall mTrackBall;
    double mExpDist;

    bool mbRenderFromCam;
    MyMainWindow* lpMyMainWindow;

    NcDataStreamBase::PacketType_t mPacketsActivated;
    NcDataStreamCamTrack mNcDataStreamCamTrack;
    NcDataStreamOpticalParameters mNcDataStreamOpticalParameters;
    NcDataStreamDistortMap mNcDataStreamDistortMap;
};
/** @}*/
#endif // GLWIDGET_H
