/*
*  Copyright (c) 2012-2014 Ncam Technologies Ltd. All rights reserved.
*  Unpublished - rights reserved under the copyright laws of the
*  United States. Use of a copyright notice is precautionary only
*  and does not imply publication or disclosure.
*  This software contains confidential information and trade secrets
*  of Ncam Technologies Limited. Use, disclosure, or reproduction
*  is prohibited without the prior express written permission of
*  Ncam Technologies Limited.
*/

#include "MyGUIClient.h"

MyGUIClient::MyGUIClient():
    QThread(),
    NcDataStreamClientBase(),
    mpTcpSocket(nullptr),
    mbThreadShouldRun(true)
{

}

MyGUIClient::~MyGUIClient()
{
    StopExec();
}

void MyGUIClient::Exec()
{
    mbThreadShouldRun.SetValue(true);
    start();
}

void MyGUIClient::StopExec()
{
    if (isRunning())
    {
        mbThreadShouldRun.SetValue(false);
        wait();
    }
}

bool MyGUIClient::IsConnected() const
{
    return (nullptr != mpTcpSocket);
}

void MyGUIClient::run()
{
    bool lRetValue = false;
    lRetValue = StartStreaming();
    while(mbThreadShouldRun.GetValue() && lRetValue)
    {
        lRetValue = DoStreaming();
    }
    StopStreaming();
}

bool MyGUIClient::InternalOpen()
{
    if (IsConnected())
    {
        return false;
    }
    mpTcpSocket = new QTcpSocket();
    //Disable nagle's algo
    mpTcpSocket->setSocketOption(QAbstractSocket::LowDelayOption,true);
    mpTcpSocket->connectToHost(QString(GetIpAddress().c_str()),GetPort());
    if (mpTcpSocket->waitForConnected(1000))
    {
        return true;
    }
    delete(mpTcpSocket);
    mpTcpSocket = nullptr;
    return false;
}

bool MyGUIClient::InternalClose()
{
    if (!IsConnected())
    {
        return false;
    }
    //Ask the Thread to Stop;
    mpTcpSocket->close();
    delete(mpTcpSocket);
    mpTcpSocket = nullptr;
    return true;
}

ssize_t MyGUIClient::InternalRead(uint8_t *data, const size_t& maxlen)
{
    ssize_t lSizeRead = -1;
    if (IsConnected())
    {
        bool lSuccess = (mpTcpSocket->bytesAvailable()>0);
        if (false == lSuccess)
            lSuccess = mpTcpSocket->waitForReadyRead(1000);
        if (lSuccess)
        {
            lSizeRead = mpTcpSocket->read((char*)data, maxlen);
        }
    }
    return lSizeRead;
}

ssize_t MyGUIClient::InternalWrite(const uint8_t *data, const size_t& maxlen)
{
    ssize_t lSizeWritten = -1;
    if (IsConnected())
    {
        bool lSuccess = false;
        lSizeWritten = mpTcpSocket->write((char*)data, maxlen);
        if (lSizeWritten>0)
        {
            lSuccess = mpTcpSocket->waitForBytesWritten(1000);
        }
        if (false == lSuccess)
        {
            lSizeWritten = -1;
        }
    }
    return lSizeWritten;
}

Packets_t& MyGUIClient::MapPackets(bool& lSuccess)
{
    lSuccess = true;
    return mDataBufferSwap.MapProductorBuffer();
}

void MyGUIClient::UnmapPackets()
{
    mDataBufferSwap.UnMapProductorBuffer();
}

bool MyGUIClient::IsNewDataToMap()
{
    return mDataBufferSwap.IsNewProductAvailable();
}

bool MyGUIClient::WaitForNewDataToMap(unsigned long luiTime)
{
    return mDataBufferSwap.WaitForNewProductAvailable(luiTime);
}

Packets_t& MyGUIClient::MapData(bool& lIsASuccess, bool lWaitForNewData, unsigned long luiTime)
{
    return mDataBufferSwap.MapConsumerBuffer(lIsASuccess,lWaitForNewData,luiTime);
}

void MyGUIClient::UnMapData()
{
     mDataBufferSwap.UnMapConsumerBuffer();
}

//Error Handling
void MyGUIClient::OnStartStreamingError(const std::string& lDescription)
{
    emit StartStreamingError(lDescription.c_str());
}

void MyGUIClient::OnStopStreamingError(const std::string& lDescription)
{
    emit StopStreamingError(lDescription.c_str());
}

void MyGUIClient::OnDoStreamingError(const std::string& lDescription)
{
    emit DoStreamingError(lDescription.c_str());
}
