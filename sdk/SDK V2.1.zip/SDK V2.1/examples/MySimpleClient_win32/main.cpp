/** \addtogroup MySimpleClient_win32
 *  @ingroup Examples
 *  @{
 */
#include <iostream>
#include <winsock2.h>
#include <ws2tcpip.h>

// To capture properly ending with CTRL-C
#include <signal.h>

#include "NcDataStreamBase.h"
#include "NcDataStreamClientBase.h"
#include "NcDataStreaming.h"
#include "NcDataStreamCamTrack.h"

// Need to link with Ws2_32.lib, Mswsock.lib, and Advapi32.lib
#pragma comment (lib, "Ws2_32.lib")
#pragma comment (lib, "Mswsock.lib")
#pragma comment (lib, "AdvApi32.lib")

class MyClient : public NcDataStreamClientBase
{
public:
    MyClient() :
        NcDataStreamClientBase(),
		mSocket(INVALID_SOCKET),
		mSocketAddr( NULL )
    {
    }
    virtual ~MyClient()
    {
    }

    /**
     * @brief Map the buffer for packet access.
     * @param lSuccess Flag indicate if the mapping success.
     * @return The last packet read through the socket.
     * @warning No concurrent access allowed!
     */
    Packets_t &MapPackets(bool &lSuccess)
    {
        lSuccess = true;
        return mDataBuffer;
    }
    /**
     * @brief Unmap the buffer.
     * @warning No concurrent access allowed!
     */
    void UnmapPackets()
    {
    }

    /**
     * @brief IsConnected is pure virtual, has to be overloaded as it depends on socket implementation.
     * @return True if the socket is opened.
     */
    bool IsConnected() const
    {
        return (INVALID_SOCKET != mSocket);
    }

protected:
    /**
     * @brief InternalOpen This function has to be overloaded with the specific socket openning process.
     * @return True if the connection can be opened, false if the socket is already openned or if the socket cannot be openned.
     */
    bool InternalOpen()
    {
        if( IsConnected() )
            return false;
		int iResult = 0;
		// Initialize Winsock
		WSADATA wsaData;
		iResult = WSAStartup(MAKEWORD(2,2), &wsaData);
		if (iResult != 0)
		{
			std::cerr << "WSAStartup failed with error: " << iResult << std::endl;
			return false;
		}
		struct addrinfo hints;
		ZeroMemory( &hints, sizeof(hints) );
		hints.ai_family = AF_UNSPEC;
		hints.ai_socktype = SOCK_STREAM;
		hints.ai_protocol = IPPROTO_TCP;
		char lPort[256];
		sprintf_s(lPort, 256, "%d", GetPort() );
        iResult = getaddrinfo( GetIpAddress().c_str(), lPort, &hints, &mSocketAddr );
		if( 0 != iResult )
		{
			std::cerr << "Unable to get socket information" << std::endl;
			WSACleanup();
			return false;
		}
		mSocket = socket( mSocketAddr->ai_family, mSocketAddr->ai_socktype, mSocketAddr->ai_protocol );
		if( mSocket == INVALID_SOCKET)
		{
			std::cerr << "Unable to open socket" << WSAGetLastError() << std::endl;
			return false;
		}
		iResult = connect( mSocket, mSocketAddr->ai_addr, (int)mSocketAddr->ai_addrlen );
		if( SOCKET_ERROR == iResult )
		{
			closesocket( mSocket );
			mSocket = INVALID_SOCKET;
		}
		if( INVALID_SOCKET == mSocket )
		{
			std::cerr << "Unable to connect to the server" << std::endl;
			WSACleanup();
			return false;
		}
        return true;
    }
    /**
     * @brief InternalClose This function has to be overloaded with socket-depend close process.
     * @return True if the socket has been closed, false if the socket wasn't opened.
     */
    bool InternalClose()
    {
        if( !IsConnected() )
            return false;
        int iResult = closesocket(mSocket);
		if (iResult == SOCKET_ERROR)
		{
			std::cerr << "Unable to close socket: " << WSAGetLastError() << std::endl;
			WSACleanup();
			return false;
		}
        WSACleanup();
        return true;
    }
    /**
     * @brief InternalRead Read a buffer of bytes.
     * @param data The buffer used to store the read bytes.
     * @param maxlen The maximum size allowed for the data buffer.
     * @return The number of bytes read.
     */
    ssize_t InternalRead(uint8_t *data, const size_t &maxlen)
    {
        ssize_t lSizeRead = -1;
		lSizeRead = recv(mSocket, (char*)data, maxlen, 0);
		if (lSizeRead >= 0)
			return lSizeRead;
		else
			std::cerr << "Reception failed: " << WSAGetLastError() << std::endl;
		lSizeRead = -1;
			exit(1);
		return lSizeRead;
    }
    /**
     * @brief InternalWrite Write to the socket (for communication to the server).
     * @param data The buffer to write through the socket.
     * @param maxlen The size of the buffer.
     * @return The number of bytes written, or -1 if the writting failed.
     */
    ssize_t InternalWrite(const uint8_t *data, const size_t &maxlen)
    {
		ssize_t lSizeWritten = send(mSocket, (char*)data, maxlen, 0);
		if( SOCKET_ERROR == lSizeWritten )
		{
			std::cerr << "Sending failed: " << WSAGetLastError() << std::endl;
			closesocket(mSocket);
			WSACleanup();
			return -1;
		}
		return lSizeWritten;
    }

protected:
    Packets_t mDataBuffer; ///< Buffer of packets.
    SOCKET mSocket;   ///< Socket object.
	struct addrinfo* mSocketAddr; ///< Structure of socket information (address, port, protocol, etc).

protected:
    /**
     * @brief OnStartStreamingError overloaded error callback when opening the connection.
     * @param lErrorDecription The error message returned by the API.
     */
    void OnStartStreamingError(const std::string &lErrorDecription)
    {
        std::cerr << std::endl << __FUNCTION__ << ": " << lErrorDecription << std::endl;
    }
    /**
     * @brief OnStopStreamingError overloaded error callback when stoping the connection.
     * @param lErrorDecription The error message returned by the API.
     */
    void OnStopStreamingError(const std::string &lErrorDecription)
    {
        std::cerr << std::endl << __FUNCTION__ << ": " << lErrorDecription << std::endl;
    }
    /**
     * @brief OnDoStreamingError overloading error callback when sending/receiving packets through the socket.
     * @param lErrorDecription The error message returned by the API.
     */
    void OnDoStreamingError(const std::string &lErrorDecription)
    {
        std::cerr << std::endl << __FUNCTION__ << ": " << lErrorDecription << std::endl;
    }
};

void ShowPacket( const NcDataStreamCamTrack::TrackingPacket& lPacket )
{
    std::cout << "TC: [" << lPacket.mTimeCode << "]"
              << " zoom: " << lPacket.mZoomEncoder.mNormalized << "/" << lPacket.mZoomEncoder.mMappedValue
              << " focus: " << lPacket.mFocusEncoder.mNormalized << "/" << lPacket.mFocusEncoder.mMappedValue
              << " iris: " << lPacket.mIrisEncoder.mNormalized << "/" << lPacket.mIrisEncoder.mMappedValue
              << "\r";
}

void DisplayPacket( MyClient* simpleClient )
{
    bool IsASucces = false;
    const Packets_t& lPackets = simpleClient->MapPackets(IsASucces);
    if (IsASucces)
    {
        {
            NcDataStreamBase::PacketType_t lSearchedPacket = NcDataStreamBase::CameraTracking;
            auto lIter = lPackets.find(lSearchedPacket);
            if (lIter !=lPackets.end())
            {
                const NcDataStreamCamTrack* lPacket = static_cast<const NcDataStreamCamTrack*> (lIter->second);
                ShowPacket(lPacket->GetData());
            }
        }
        simpleClient->UnmapPackets();
    }
}


MyClient* simpleClient = nullptr;

void signal_callback_handler(int /*signum*/)
{
    // Properly close the streaming
    if( nullptr != simpleClient )
    {
        simpleClient->StopStreaming();
        delete simpleClient;
        simpleClient = nullptr;
    }

    std::cout << std::endl;

   // Terminate program
   exit(0);
}

int main(int argc, char *argv[])
{
    // Register signal and signal handler
    signal(SIGINT, signal_callback_handler);

    uint16_t ip_port = 38860;
    std::string ip_address;

    if( 2 == argc )
    {
        ip_address = std::string( argv[ 1 ] );
    }
    else
    {
        std::cerr << "Usage: " << argv[0] << " IP" << std::endl
                  << "where IP is the IPv4 address of the server running tracking. (Port is 38860)" << std::endl;
        return -1;
    }

    simpleClient = new MyClient();

    simpleClient->SetConnectionParameters( ip_address, ip_port );

    if(simpleClient->StartStreaming())
    {
        std::cout << "Properly end the streaming with CTRL-C" << std::endl;
        while(simpleClient->DoStreaming())
        {
            DisplayPacket( simpleClient );
        }
    }

    simpleClient->StopStreaming();
    delete simpleClient;
    simpleClient = nullptr;

    return 0;
}
/** @}*/
