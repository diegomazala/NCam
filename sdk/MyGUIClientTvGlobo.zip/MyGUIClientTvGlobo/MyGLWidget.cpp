/*
*  Copyright (c) 2012 Ncam. All rights reserved.
*  Unpublished - rights reserved under the copyright laws of the
*  UK. Use of a copyright notice is precautionary only
*  and does not imply publication or disclosure.
*  This software contains confidential information and trade secrets
*  of Ncam Solutions Limited. Use, disclosure, or reproduction
*  is prohibited without the prior express written permission of
*  Ncam Solutions Limited.
*/

#include <QtGui>
#include <QtOpenGL>
#include <cassert>
#include "MyGLWidget.h"
#include "MyMainWindowTvGlobo.h"
#include <NcDataStreamCamTrackHelper.h>
#include <NcDataStreamOpticalParametersHelper.h>
#include <iostream>
MyGLWidget::MyGLWidget(MyMainWindowTvGlobo *parent):
    QGLWidget(QGLFormat(QGL::SampleBuffers|QGL::AlphaChannel|QGL::DirectRendering|QGL::DoubleBuffer),parent),
    mMySimpleCompositor(),
    mTrackBall(0.00, QVector3D(0, 1, 0), MyTrackBall::Sphere),
    mExpDist(600),
    mbRenderFromCam(false),
    lpMyMainWindow(parent),
    mPacketsActivated(NcDataStreamBase::UnknownType),
    mNcDataStreamCamTrack(),
    mNcDataStreamOpticalParameters(),
    mNcDataStreamDistortMap()
{
    assert(parent);
    startTimer(5);
    mNcDataStreamOpticalParameters.GetData().mFovInDegrees[0] = 60;
    mNcDataStreamOpticalParameters.GetData().mFovInDegrees[1] = 60;
}

MyGLWidget::~MyGLWidget()
{

}

void MyGLWidget::timerEvent(QTimerEvent* event)
{
    event->accept();
    repaint();
}

QSize MyGLWidget::minimumSizeHint() const
{
    return QSize(50, 50);
}

QSize MyGLWidget::sizeHint() const
{
    return QSize(200, 200);
}

NcDataStreamBase::PacketType_t& MyGLWidget::GetPacketsActivated()
{
    return mPacketsActivated;
}

const NcDataStreamBase::PacketType_t& MyGLWidget::GetPacketsActivated() const
{
    return mPacketsActivated;
}

NcDataStreamCamTrack& MyGLWidget::GetCamTrack()
{
    return mNcDataStreamCamTrack;
}

const NcDataStreamCamTrack& MyGLWidget::GetCamTrack() const
{
    return mNcDataStreamCamTrack;
}

NcDataStreamOpticalParameters& MyGLWidget::GetOpticalParams()
{
    return mNcDataStreamOpticalParameters;
}

const NcDataStreamOpticalParameters& MyGLWidget::GetOpticalParams() const
{
    return mNcDataStreamOpticalParameters;
}

NcDataStreamDistortMap& MyGLWidget::GetDistortMap()
{
    return mNcDataStreamDistortMap;
}

const NcDataStreamDistortMap& MyGLWidget::GetDistortMap() const
{
    return mNcDataStreamDistortMap;
}

void MyGLWidget::SetRenderFromCam(bool lValue)
{
    mbRenderFromCam = lValue;
}

void MyGLWidget::initializeGL()
{
    mMySimpleCompositor.InitializeGL();
    glEnable(GL_DEPTH_TEST);
}

void MyGLWidget::paintGL()
{
    // If we want to render the geometry from the Film Camera Point of view
    if (mbRenderFromCam)
    {
        // We can distort the rendering only when we are getting the distormap, the CameraTracking and the OpticalParameters.
        if ((mPacketsActivated & NcDataStreamBase::DistortMap)
                &&(mPacketsActivated & NcDataStreamBase::CameraTracking)
                &&(mPacketsActivated & NcDataStreamBase::OpticalParameters)
                )
        {
            glClearColor(0.7f,0.7f,0.7f,1.0f);
            //Force the rendering to keep the FilmCamera Aspect ratio, otherwise the distormap will male no sense.
            mMySimpleCompositor.SetAspectRatioViewport((uint32_t)width(), (uint32_t)height(),mNcDataStreamOpticalParameters.GetData().mImageAspectRatio);
            mMySimpleCompositor.BeginRenderCGToTexture(mNcDataStreamOpticalParameters.GetData(),GetCamTrack().GetData());
            {
                RenderGrid();
            }
            mMySimpleCompositor.EndRenderCGToTexture();
            mMySimpleCompositor.DoCompositing(mNcDataStreamDistortMap);
        }
        else
        {
            // In this case we will render as if the Camera lens had no distortions, ie. using the FOV.
            glViewport(0,0, width(), height());
            glClearColor(0.7f,0.7f,0.7f,1.0f);
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
            glMatrixMode(GL_PROJECTION);
            glLoadIdentity();
            QMatrix4x4 ProjectionMatrix;
            ProjectionMatrix.perspective (mNcDataStreamOpticalParameters.GetData().mFovInDegrees[0], width()/(double)height(), 0.1, 1000 );

            // Note that the Camera optical axis is Z ( Opengl Projection Function uses a -Z optical axis)
            // Updates the parameters to fit that constraint.
            GLdouble Projection[16];
            NcDataStreamCamHelper::CorrectZDirection(ProjectionMatrix.data(),Projection);
            glMultMatrixd(Projection);

            GLdouble ModelView[16];
            NcDataStreamCamHelper::ToOpenGLModelView(GetCamTrack().GetData(),ModelView);

            glMatrixMode(GL_MODELVIEW);
            glPushMatrix();
            {
                glLoadIdentity();
                glMultMatrixd(ModelView);
                RenderGrid();
            }
            glPopMatrix();
        }
    }
    else
    {
        // In this case we are rendering the grid and the film camera position from a user's point of view.
        glViewport(0,0, width(), height());
        glClearColor(0.7f,0.7f,0.7f,1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        QMatrix4x4 ProjectionMatrix;
        ProjectionMatrix.perspective (mNcDataStreamOpticalParameters.GetData().mFovInDegrees[0], width()/(double)height(), 0.1, 1000 );

        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glMultMatrixd(ProjectionMatrix.data());

        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

        QMatrix4x4 view;
        view.rotate(mTrackBall.GetRotation());
        view(2, 3) -= 2.0 * exp(mExpDist / 1200.0);
        glMultMatrixd(view.data());

        GLdouble ViewModel[16];
        NcDataStreamCamHelper::ToOpenGLViewModel(GetCamTrack().GetData(),ViewModel);
        glMatrixMode(GL_MODELVIEW);
        glPushMatrix();
        {
            glMultMatrixd(ViewModel);
            // Simple Camera Model Geometry
            glBegin(GL_LINES);
            {
                glColor4d(1.0,1.0,1.0,1.0);
                glVertex3d(-0.12, -0.1, 0.2);
                glVertex3d( 0.12, -0.1, 0.2);
                glVertex3d( 0.12, -0.1, 0.2);
                glVertex3d( 0.12, 0.1, 0.2);
                glVertex3d( 0.12, 0.1, 0.2);
                glVertex3d(-0.12, 0.1, 0.2);
                glVertex3d(-0.12, 0.1, 0.2);
                glVertex3d(-0.12, -0.1, 0.2);
                glVertex3d(0.0, 0.0, 0.0);
                glVertex3d(-0.12, -0.1, 0.2);
                glVertex3d(0.0, 0.0, 0.0);
                glVertex3d( 0.12, -0.1, 0.2);
                glVertex3d(0.0, 0.0, 0.0);
                glVertex3d( 0.12, 0.1, 0.2);
                glVertex3d(0.0, 0.0, 0.0);
                glVertex3d( -0.12, 0.1, 0.2);
            }
            glEnd();
            glLineWidth(3);
            glBegin(GL_LINES);
            glColor4d(1.0,0.0,0.0,1.0);
            glVertex3d(0.0, 0.0, 0.0);
            glVertex3d(0.1, 0.0, 0.0);

            glColor4d(0.0,1.0,0.0,1.0);
            glVertex3d(0.0, 0.0, 0.0);
            glVertex3d(0.0, 0.1, 0.0);

            glColor4d(0.0,0.0,1.0,1.0);
            glVertex3d(0.0, 0.0, 0.0);
            glVertex3d(0.0, 0.0, 0.1);
            glEnd();

            glLineWidth(1);
        }
        glPopMatrix();
        RenderGrid();
    }
}

void MyGLWidget::resizeGL(int, int)
{
    repaint();
}

void MyGLWidget::mousePressEvent(QMouseEvent *event)
{
    if (false == mbRenderFromCam)
        if (event->buttons() & Qt::LeftButton)
        {
            mTrackBall.Push(PixelPosToViewPos(event->pos()), QQuaternion());
            event->accept();
            repaint();
        }
}

void MyGLWidget::mouseMoveEvent(QMouseEvent *event)
{
    if (false == mbRenderFromCam)
    {
        if (event->buttons() & Qt::LeftButton)
        {
            mTrackBall.Move(PixelPosToViewPos(event->pos()), QQuaternion());
            event->accept();
            repaint();
        }
        else
        {
            mTrackBall.Release(event->pos(), QQuaternion());
            event->accept();
            repaint();
        }
    }
}

void MyGLWidget::mouseReleaseEvent(QMouseEvent * event)
{
    if (false == mbRenderFromCam)
        if (event->button() == Qt::LeftButton)
        {
            mTrackBall.Release(PixelPosToViewPos(event->pos()), QQuaternion());
            event->accept();
            repaint();
        }
}
void MyGLWidget::wheelEvent(QWheelEvent *event)
{
    if (false == mbRenderFromCam)
    {
        mExpDist += event->delta();
        if (mExpDist < -80 * 120)
            mExpDist = -80 * 120;
        if (mExpDist > 100 * 120)
            mExpDist = 100 * 120;
        event->accept();
        repaint();
    }
}

void MyGLWidget::RenderGrid()
{
    glDisable(GL_COLOR_MATERIAL);
    glDisable(GL_LIGHTING);
    glEnable(GL_LINE_SMOOTH);
    glLineWidth(3);

    glBegin(GL_LINES);
    glColor4d(1.0,0.0,0.0,1.0);
    glVertex3d(0.0, 0.0, 0.0);
    glVertex3d(0.1, 0.0, 0.0);

    glColor4d(0.0,1.0,0.0,1.0);
    glVertex3d(0.0, 0.0, 0.0);
    glVertex3d(0.0, 0.1, 0.0);

    glColor4d(0.0,0.0,1.0,1.0);
    glVertex3d(0.0, 0.0, 0.0);
    glVertex3d(0.0, 0.0, 0.1);
    glEnd();

    glLineWidth(1);

    glBegin(GL_LINES);
    for(int x=-10; x<=10; x++)
    {
        if(x==0)
            glColor4d(1.0,1.0,1.0,1.0);
        else
            glColor4d(0.3,0.3,0.3,1.0);
        glVertex3d(x , 0.0, -10.0);
        glVertex3d(x , 0.0, 10.0);
    }

    for(int y=-10; y<=10; y++)
    {
        if(y==0)
            glColor4d(1.0,1.0,1.0,1.0);
        else
            glColor4d(0.3,0.3,0.3,1.0);

        glVertex3d(-10.0 , 0.0, y);
        glVertex3d(10.0 , 0.0, y);
    }
    glEnd();
}
