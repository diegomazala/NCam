/*
*  Copyright (c) 2012-2014 Ncam Technologies Ltd. All rights reserved.
*  Unpublished - rights reserved under the copyright laws of the
*  United States. Use of a copyright notice is precautionary only
*  and does not imply publication or disclosure.
*  This software contains confidential information and trade secrets
*  of Ncam Technologies Limited. Use, disclosure, or reproduction
*  is prohibited without the prior express written permission of
*  Ncam Technologies Limited.
*/

#ifndef NCDATASTREAMCLIENT_H
#define NCDATASTREAMCLIENT_H
/** \addtogroup MyGUIClientTvGlobo
 *  @{
 */
#include <QThread>
#include <QTcpSocket>
#include <NcDataStreamClientBase.h>
#include <NcThreadSafeTools.h>
///
/// \brief The MyGUIClient reimplements NcDataStreamClientBase.
///
class MyGUIClientTvGlobo: public QThread, public NcDataStreamClientBase
{
    Q_OBJECT
public:
    MyGUIClientTvGlobo();
    virtual ~MyGUIClientTvGlobo();
    //Here are all the methods we need to redefine.
    virtual bool IsConnected() const;

    void Exec();
    void StopExec();


    //Frame Access
    bool IsNewFrameDataToMap();
    bool WaitForNewFrameDataToMap(unsigned long luiTime);
    std::pair<Packets_t,Packets_t> & MapFrameData(bool &lIsASuccess, bool lWaitForNewData, unsigned long luiTime);
    void UnMapFrameData();

signals:
    void StartStreamingError(QString lDescription);
    void StopStreamingError(QString lDescription);
    void DoStreamingError(QString lDescription);

protected:
    //Error Handling
    virtual void OnStartStreamingError(const std::string& lErrorDecription = std::string());
    virtual void OnStopStreamingError(const std::string& lErrorDecription = std::string());
    virtual void OnDoStreamingError(const std::string& lErrorDecription = std::string());

    // This is the method called in the thread
    virtual void run();

    virtual bool InternalOpen();
    virtual bool InternalClose();

    virtual ssize_t InternalRead(uint8_t *data, const size_t& maxlen);
    virtual ssize_t InternalWrite(const uint8_t *data, const size_t& maxlen);

    virtual Packets_t& MapPackets(bool& lSuccess) ;
    virtual void UnmapPackets();
private:
    QTcpSocket* mpTcpSocket;

    //Should be protected by a mutex
    NcThreadSafeResource<bool> mbThreadShouldRun;
    NcDataBufferSwap<std::pair<Packets_t,Packets_t>> mFrameDataBufferSwap;

    // No need to protect the following data as there is only one thread that will access to this.
    std::pair<Packets_t,Packets_t>*  mCachedPackets;
    uint32_t mLastPacketId;
};
/** @}*/

#endif // NCDATASTREAMCLIENT_H
