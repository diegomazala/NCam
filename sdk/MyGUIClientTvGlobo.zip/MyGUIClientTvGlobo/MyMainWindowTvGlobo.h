/*
*  Copyright (c) 2012-2014 Ncam Technologies Ltd. All rights reserved.
*  Unpublished - rights reserved under the copyright laws of the
*  United States. Use of a copyright notice is precautionary only
*  and does not imply publication or disclosure.
*  This software contains confidential information and trade secrets
*  of Ncam Technologies Limited. Use, disclosure, or reproduction
*  is prohibited without the prior express written permission of
*  Ncam Technologies Limited.
*/

#ifndef MYMAINWINDOW_H
#define MYMAINWINDOW_H

/** \addtogroup MyGUIClient
 *  @{
 */

#include <QMainWindow>
#include <NcDataStreamCamTrack.h>
#include <NcDataStreamOpticalParameters.h>

class NcDataStreamCapabilities;
class MyGUIClientTvGlobo;
class MyGLWidget;
class QTime;

namespace Ui {
class MyMainWindow;
}

class MyMainWindowTvGlobo : public QMainWindow
{
    Q_OBJECT

public:
    explicit MyMainWindowTvGlobo(QWidget *parent = 0);
    ~MyMainWindowTvGlobo();
protected:
    void UpdateGUIFromCapabilities(const NcDataStreamCapabilities& lNcDataStreamCapabilities, bool lForceDisabled = false);
    void UpdateCameraTrackingGUI(const NcDataStreamCamTrack::TrackingPacket& lTrackingPacket);
    void UpdateLensParamGUI(const NcDataStreamOpticalParameters::OpticalParametersPacket & lPacket);

    MyGUIClientTvGlobo* mpMyGUIClientTvGlobo;
    MyGLWidget* mpMyGLWidget;

    void ComputeStats(unsigned int lMinNbSample = 50);
    void AckOnePacket();

private slots:
    void OnCheckDataFromClient();
    void on_ConnectLabel_clicked();
    void on_DisconnectLabel_clicked();
    void on_PacketsToStreamUpdate_clicked();
    void OnPacketsActivatedChanged();
    void on_RenderFromCamCheckBox_toggled(bool checked);
    void OnClientError(QString lDescription);

private:

    NcDataStreamBase::PacketType_t GetActivatedFromGuiPackets();
    Ui::MyMainWindow *ui;
    const quint16 mDefaultPort;

    QTime *mpCurrTime;
    quint32 mNbPackets;
    float mSamplesPerSecond;
};
/** @}*/

#endif // MYMAINWINDOW_H
