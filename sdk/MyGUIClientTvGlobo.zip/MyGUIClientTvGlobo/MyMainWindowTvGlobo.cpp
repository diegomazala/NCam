/*
*  Copyright (c) 2012-2014 Ncam Technologies Ltd. All rights reserved.
*  Unpublished - rights reserved under the copyright laws of the
*  United States. Use of a copyright notice is precautionary only
*  and does not imply publication or disclosure.
*  This software contains confidential information and trade secrets
*  of Ncam Technologies Limited. Use, disclosure, or reproduction
*  is prohibited without the prior express written permission of
*  Ncam Technologies Limited.
*/

#include "MyMainWindowTvGlobo.h"
#include <MyGUIClientTvGlobo.h>

#include "ui_MyMainWindowTvGlobo.h"
#include <QMessageBox>
#include <NcDataStreamCamTrackHelper.h>
#include <MyGLWidget.h>
#include <QDebug>

MyMainWindowTvGlobo::MyMainWindowTvGlobo(QWidget *parent) :
    QMainWindow(parent),
    mpMyGUIClientTvGlobo(nullptr),
    mpMyGLWidget(nullptr),
    ui(new Ui::MyMainWindow),
    mDefaultPort(38860),
    mpCurrTime(nullptr),
    mNbPackets(0),
    mSamplesPerSecond(0.0)
{
    ui->setupUi(this);
    connect(ui->CameraTrackingCheckBox,SIGNAL(clicked()),SLOT(OnPacketsActivatedChanged()));
    connect(ui->CompositeImageCheckBox,SIGNAL(clicked()),SLOT(OnPacketsActivatedChanged()));
    connect(ui->DepthImageCheckBox,SIGNAL(clicked()),SLOT(OnPacketsActivatedChanged()));
    connect(ui->FilmImageCheckBox,SIGNAL(clicked()),SLOT(OnPacketsActivatedChanged()));
    connect(ui->OpticalParametersCheckBox,SIGNAL(clicked()),SLOT(OnPacketsActivatedChanged()));
    connect(ui->DistortMapCheckBox,SIGNAL(clicked()),SLOT(OnPacketsActivatedChanged()));

    mpMyGUIClientTvGlobo = new MyGUIClientTvGlobo();
    mpMyGLWidget = new MyGLWidget(this);
    ui->verticalLayout_2->addWidget(mpMyGLWidget);
    ui->DisconnectLabel->setEnabled(false);
    QTimer * lpTimer = new QTimer(this);
    connect(lpTimer,SIGNAL(timeout()),SLOT(OnCheckDataFromClient()));
    lpTimer->start(5);
    connect(mpMyGUIClientTvGlobo,SIGNAL(StartStreamingError(QString)),SLOT(OnClientError(QString)));
    connect(mpMyGUIClientTvGlobo,SIGNAL(DoStreamingError(QString)),SLOT(OnClientError(QString)));
    mpCurrTime = new QTime();
    mpCurrTime->start();
}

MyMainWindowTvGlobo::~MyMainWindowTvGlobo()
{
    delete ui;
    if (nullptr!= mpMyGUIClientTvGlobo)
    {
        delete(mpMyGUIClientTvGlobo);
        mpMyGUIClientTvGlobo = nullptr;
    }
}

void MyMainWindowTvGlobo::ComputeStats(unsigned int lMinNbSample)
{
    if (mNbPackets > lMinNbSample || mpCurrTime->elapsed()>2000)
    {
        float lSampleTimeInSeconds = mpCurrTime->elapsed()/1000.0;
        mSamplesPerSecond = (mNbPackets)/lSampleTimeInSeconds;
        mpCurrTime->restart();
        mNbPackets = 0;
        ui->statusBar->showMessage("FPS: " + QString("%1").arg(mSamplesPerSecond));
    }
}

void MyMainWindowTvGlobo::AckOnePacket()
{
    mNbPackets++;
}

void MyMainWindowTvGlobo::on_ConnectLabel_clicked()
{
    //Set the connection Parameters
    mpMyGUIClientTvGlobo->SetConnectionParameters(ui->IpAddressValue->text().toStdString(),mDefaultPort);
    // Update the list of packets to activate
    ui->CameraTrackingCheckBox->setEnabled(false);
    ui->DepthImageCheckBox->setEnabled(false);
    ui->FilmImageCheckBox->setEnabled(false);
    ui->CompositeImageCheckBox->setEnabled(false);
    ui->DistortMapCheckBox->setEnabled(false);
    ui->OpticalParametersCheckBox->setEnabled(false);

    mpMyGUIClientTvGlobo->Exec();
    ui->ConnectLabel->setEnabled(false);
    ui->DisconnectLabel->setEnabled(true);
    ui->PacketsToStreamUpdate->setEnabled(false);
}

void MyMainWindowTvGlobo::on_DisconnectLabel_clicked()
{
    if (mpMyGUIClientTvGlobo->IsConnected())
        mpMyGUIClientTvGlobo->StopExec();

    ui->ConnectLabel->setEnabled(true);
    ui->DisconnectLabel->setEnabled(false);
    ui->PacketsToStreamUpdate->setEnabled(true);
}

void MyMainWindowTvGlobo::on_PacketsToStreamUpdate_clicked()
{
    mpMyGUIClientTvGlobo->SetConnectionParameters(ui->IpAddressValue->text().toStdString(),mDefaultPort);
    bool lCapabilitiesAreAvailable = false;
    const NcDataStreamCapabilities& lCapabilities = mpMyGUIClientTvGlobo->GetCapabilities(lCapabilitiesAreAvailable);
    if (lCapabilitiesAreAvailable)
    {
        //We should Update The GUI with all the options available.
        UpdateGUIFromCapabilities(lCapabilities);
    }
    else
    {
        QMessageBox::critical(this,tr("Error"),tr("Unable to get the capabilities\n Is the server started and the Ip adress correct ?"),QMessageBox::Close);
    }
}

NcDataStreamBase::PacketType_t MyMainWindowTvGlobo::GetActivatedFromGuiPackets()
{
    NcDataStreamBase::PacketType_t lPacketsToActivate = NcDataStreamBase::UnknownType;
    if (ui->CameraTrackingCheckBox->isChecked()) lPacketsToActivate = (lPacketsToActivate    | NcDataStreamBase::CameraTracking);
    if (ui->DepthImageCheckBox->isChecked()) lPacketsToActivate = (lPacketsToActivate        | NcDataStreamBase::DepthImage);
    if (ui->FilmImageCheckBox->isChecked()) lPacketsToActivate = (lPacketsToActivate         | NcDataStreamBase::FilmImage);
    if (ui->CompositeImageCheckBox->isChecked()) lPacketsToActivate = (lPacketsToActivate    | NcDataStreamBase::CompositeImage);
    if (ui->DistortMapCheckBox->isChecked()) lPacketsToActivate = (lPacketsToActivate        | NcDataStreamBase::DistortMap);
    if (ui->OpticalParametersCheckBox->isChecked()) lPacketsToActivate = (lPacketsToActivate | NcDataStreamBase::OpticalParameters);
    return lPacketsToActivate;
}
void MyMainWindowTvGlobo::UpdateGUIFromCapabilities(const NcDataStreamCapabilities& lNcDataStreamCapabilities, bool lForceDisabled)
{
    {
        NcDataStreamBase::PacketType_t lPackets  = (lNcDataStreamCapabilities.GetData().mAvailablePackets & NcDataStreamBase::TypeMask);
        if (lForceDisabled)
        {
            lPackets = NcDataStreamBase::UnknownType;
        }
        ui->CameraTrackingCheckBox->setEnabled((lPackets & NcDataStreamBase::CameraTracking)!=0x0000);
        ui->DepthImageCheckBox->setEnabled((lPackets & NcDataStreamBase::DepthImage)!=0x0000);
        ui->FilmImageCheckBox->setEnabled((lPackets & NcDataStreamBase::FilmImage)!=0x0000);
        ui->CompositeImageCheckBox->setEnabled((lPackets & NcDataStreamBase::CompositeImage)!=0x0000);
        ui->DistortMapCheckBox->setEnabled((lPackets & NcDataStreamBase::DistortMap)!=0x0000);
        ui->OpticalParametersCheckBox->setEnabled((lPackets & NcDataStreamBase::OpticalParameters)!=0x0000);
    }

    {
        NcDataStreamBase::PacketType_t lPackets  = lNcDataStreamCapabilities.GetData().mAvailablePackets &(lNcDataStreamCapabilities.GetData().mActivatedPackets & NcDataStreamBase::TypeMask);
        ui->CameraTrackingCheckBox->setChecked((lPackets & NcDataStreamBase::CameraTracking)!=0x0000);
        ui->DepthImageCheckBox->setChecked((lPackets & NcDataStreamBase::DepthImage)!=0x0000);
        ui->FilmImageCheckBox->setChecked((lPackets & NcDataStreamBase::FilmImage)!=0x0000);
        ui->CompositeImageCheckBox->setChecked((lPackets & NcDataStreamBase::CompositeImage)!=0x0000);
        ui->DistortMapCheckBox->setChecked((lPackets & NcDataStreamBase::DistortMap)!=0x0000);
        ui->OpticalParametersCheckBox->setChecked((lPackets & NcDataStreamBase::OpticalParameters)!=0x0000);
        //Lets update the renderer from the activated packets
        mpMyGLWidget->GetPacketsActivated() = lPackets;
    }
}

void MyMainWindowTvGlobo::UpdateLensParamGUI(const NcDataStreamOpticalParameters::OpticalParametersPacket & lPacket)
{
    ui->OpticalParametersGroupBox->setEnabled(true);
    //TimeCode
    quint32 lHours, lMinutes,lSeconds,lFrames;
    quint8 lDropFrame;
    NcDataStreamCamHelper::DecodeTimeCode(lPacket.mTimeCode,lHours,lMinutes,lSeconds,lFrames,lDropFrame);
    ui->OpticalHoursValue->setValue(lHours);
    ui->OpticalMinutesValue->setValue(lMinutes);
    ui->OpticalSecondsValue->setValue(lSeconds);
    ui->OpticalFramesValue->setValue(lFrames);

    //Fov
    ui->HFOVValue->setValue(lPacket.mFovInDegrees[0]);
    ui->VFOVValue->setValue(lPacket.mFovInDegrees[1]);

    // LensOffset
    ui->HOpticalCenterValue->setValue(lPacket.mProjectionCenterNormalized[0]);
    ui->VOpticalCenterValue->setValue(lPacket.mProjectionCenterNormalized[1]);

    // SensorSize
    ui->HSensorSize->setValue(lPacket.mImageSensorSizeInMm[0]);
    ui->VSensorSize->setValue(lPacket.mImageSensorSizeInMm[1]);

    // SensorResolution
    ui->HImageResolution->setValue(lPacket.mImageResolution[0]);
    ui->VImageResolution->setValue(lPacket.mImageResolution[1]);

    ui->Top->setValue(lPacket.mTop);
    ui->Bottom->setValue(lPacket.mBottom);
    ui->Left->setValue(lPacket.mLeft);
    ui->Right->setValue(lPacket.mRight);
    ui->AspectRatio->setValue(lPacket.mImageAspectRatio);

}

void MyMainWindowTvGlobo::UpdateCameraTrackingGUI(const NcDataStreamCamTrack::TrackingPacket& lTrackingPacket)
{
    ui->TrackinPacketsGroupBox->setEnabled(true);
    //TimeCode
    quint32 lHours, lMinutes,lSeconds,lFrames;
    quint8 lDropFrame;
    NcDataStreamCamHelper::DecodeTimeCode(lTrackingPacket.mTimeCode,lHours,lMinutes,lSeconds,lFrames,lDropFrame);
    //qDebug() << lHours <<":"<< lMinutes<<":" << lSeconds<<":" << lFrames;
    ui->HoursValue->setValue(lHours);
    ui->MinutesValue->setValue(lMinutes);
    ui->SecondsValue->setValue(lSeconds);
    ui->FramesValue->setValue(lFrames);

    //Encoders
    ui->ZoomNormalized->setValue(lTrackingPacket.mZoomEncoder.mNormalized);
    ui->ZoomValue->setValue(lTrackingPacket.mZoomEncoder.mMappedValue);

    ui->FocusNormalized->setValue(lTrackingPacket.mFocusEncoder.mNormalized);
    ui->FocusValue->setValue(lTrackingPacket.mFocusEncoder.mMappedValue);

    ui->IrisNormalized->setValue(lTrackingPacket.mIrisEncoder.mNormalized);
    ui->IrisValue->setValue(lTrackingPacket.mIrisEncoder.mMappedValue);

    //RigidTransfor
    ui->TransValue_0->setValue(lTrackingPacket.mCamFromWorld.mTranslation[0]);
    ui->TransValue_1->setValue(lTrackingPacket.mCamFromWorld.mTranslation[1]);
    ui->TransValue_2->setValue(lTrackingPacket.mCamFromWorld.mTranslation[2]);

    ui->RotValue_00->setValue(lTrackingPacket.mCamFromWorld.mRotation[0]);
    ui->RotValue_01->setValue(lTrackingPacket.mCamFromWorld.mRotation[1]);
    ui->RotValue_02->setValue(lTrackingPacket.mCamFromWorld.mRotation[2]);

    ui->RotValue_10->setValue(lTrackingPacket.mCamFromWorld.mRotation[3]);
    ui->RotValue_11->setValue(lTrackingPacket.mCamFromWorld.mRotation[4]);
    ui->RotValue_12->setValue(lTrackingPacket.mCamFromWorld.mRotation[5]);

    ui->RotValue_20->setValue(lTrackingPacket.mCamFromWorld.mRotation[6]);
    ui->RotValue_21->setValue(lTrackingPacket.mCamFromWorld.mRotation[7]);
    ui->RotValue_22->setValue(lTrackingPacket.mCamFromWorld.mRotation[8]);
}

void MyMainWindowTvGlobo::OnCheckDataFromClient()
{
    if (nullptr != mpMyGUIClientTvGlobo)
    {
        if (mpMyGUIClientTvGlobo->IsConnected())
        {
            if (mpMyGUIClientTvGlobo->IsNewFrameDataToMap())
            {
                // This is only for the exercise, then we will display the values of the first field only
                bool IsASucces = false;
                const std::pair<Packets_t,Packets_t>& lFramePackets = mpMyGUIClientTvGlobo->MapFrameData(IsASucces,true,1000);
                const Packets_t& lPackets = lFramePackets.first;
                if (IsASucces)
                {
                    AckOnePacket();
                    //Get the CamTrack Packet.
                    {
                        NcDataStreamBase::PacketType_t lSearchedPacket = NcDataStreamBase::CameraTracking;
                        auto lIter = lPackets.find(lSearchedPacket);
                        if (lIter !=lPackets.end())
                        {
                            const NcDataStreamCamTrack* lPacket = static_cast<const NcDataStreamCamTrack*> (lIter->second);
                            UpdateCameraTrackingGUI(lPacket->GetData());
                            //Lets Give this to the Renderer
                            mpMyGLWidget->GetCamTrack().FromPtr(lPacket->ToPtr(),lPacket->GetSizeInBytes());
                        }
                        else
                        {
                            ui->TrackinPacketsGroupBox->setEnabled(false);
                        }
                    }

                    //Get optical parameters if any
                    {
                        NcDataStreamBase::PacketType_t lSearchedPacket = NcDataStreamBase::OpticalParameters;
                        auto lIter = lPackets.find(lSearchedPacket);
                        if (lIter !=lPackets.end())
                        {
                            const NcDataStreamOpticalParameters* lPacket = static_cast<const NcDataStreamOpticalParameters*> (lIter->second);
                            UpdateLensParamGUI(lPacket->GetData());
                            //Lets Give this to the Renderer
                            mpMyGLWidget->GetOpticalParams().FromPtr(lPacket->ToPtr(),lPacket->GetSizeInBytes());
                        }
                        else
                        {
                            ui->OpticalParametersGroupBox->setEnabled(false);
                        }
                    }

                    //Get DistortMap if any
                    {
                        NcDataStreamBase::PacketType_t lSearchedPacket = NcDataStreamBase::DistortMap;
                        auto lIter = lPackets.find(lSearchedPacket);
                        if (lIter !=lPackets.end())
                        {
                            const NcDataStreamDistortMap* lPacket = static_cast<const NcDataStreamDistortMap*> (lIter->second);
                            //Lets Give this to the Renderer
                            mpMyGLWidget->GetDistortMap().FromPtr(lPacket->ToPtr(),lPacket->GetSizeInBytes());
                        }
                    }
                    // Once we finished to use the data, we give them back to the client
                    mpMyGUIClientTvGlobo->UnMapFrameData();
                }
            }
        }
        else
        {
             ui->TrackinPacketsGroupBox->setEnabled(false);
             ui->OpticalParametersGroupBox->setEnabled(false);
        }
    }
    ComputeStats();
}



void MyMainWindowTvGlobo::OnPacketsActivatedChanged()
{
    NcDataStreamBase::PacketType_t lActivatedPackets = GetActivatedFromGuiPackets();
    bool lbSuccess = mpMyGUIClientTvGlobo->AskForPackets(lActivatedPackets);
    if (false == lbSuccess)
    {
          QMessageBox::critical(this,tr("Error"),tr("Unable to get the capabilities\n Is the server started and the Ip adress correct ?"),QMessageBox::Close);
    }
    else
    {
        bool lCapabilitiesAreAvailable = true;
        const NcDataStreamCapabilities& lCapabilities = mpMyGUIClientTvGlobo->GetCapabilities(lCapabilitiesAreAvailable);
        if (lCapabilitiesAreAvailable)
            UpdateGUIFromCapabilities(lCapabilities);
    }
}

void MyMainWindowTvGlobo::on_RenderFromCamCheckBox_toggled(bool checked)
{
    mpMyGLWidget->SetRenderFromCam(checked);
}

void MyMainWindowTvGlobo::OnClientError(QString lDescription)
{
    if (lDescription.isEmpty())
        QMessageBox::critical(this,tr("Error"),tr("Unable to get a stable Connection to the server \n Is the server started and the Ip adress correct ?"),QMessageBox::Close);
    else
        QMessageBox::critical(this,tr("Error"),lDescription + tr("\nIs the server started and the Ip adress correct ?"),QMessageBox::Close);
    on_DisconnectLabel_clicked();
}
