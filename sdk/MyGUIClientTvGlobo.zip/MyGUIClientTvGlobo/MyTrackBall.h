/*
*  Copyright (c) 2012 Ncam. All rights reserved.
*  Unpublished - rights reserved under the copyright laws of the
*  UK. Use of a copyright notice is precautionary only
*  and does not imply publication or disclosure.
*  This software contains confidential information and trade secrets
*  of Ncam Solutions Limited. Use, disclosure, or reproduction
*  is prohibited without the prior express written permission of
*  Ncam Solutions Limited.
*/

#ifndef NCTRACKBALL_H
#define NCTRACKBALL_H

/** \addtogroup MyGUIClientTvGlobo
 *  @{
 */

#include <QtGui>
#include <QtGui/qvector3d.h>
#include <QtGui/qquaternion.h>

/// \class NcTrackBall
/// \brief Implements a trackball used to rotate am opengl scene.
class MyTrackBall
 {
public:
    enum TrackMode
     {
        Plane,
        Sphere
    };
    MyTrackBall(TrackMode mode = Sphere);
    MyTrackBall(double angularVelocity, const QVector3D& axis, TrackMode mode = Sphere);

    // coordinates in [-1,1]x[-1,1]
    void Push(const QPointF& p, const QQuaternion &transformation);
    void Move(const QPointF& p, const QQuaternion &transformation);
    void Release(const QPointF& p, const QQuaternion &transformation);
    void StartClock();
    void StopClock();
    QQuaternion GetRotation() const;

private:
    QQuaternion mRotation;
    QVector3D mAxis;
    double mAngularVelocity;

    QPointF mLastPos;
    QTime mLastTime;
    bool mbPaused;
    bool mbPressed;
    TrackMode mCurrentMode;
};
/** @}*/

#endif // NCTRACKBALL_H
